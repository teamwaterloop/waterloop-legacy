# Software to run on laptop to recieve data via network connection, parse and display

from pyqtgraph.Qt import QtGui, QtCore
import numpy as np
import pyqtgraph as pg
from socket import socket, gethostbyname, AF_INET, SOCK_DGRAM
import sys

# Modified From https://github.com/pyqtgraph/pyqtgraph/blob/develop/examples/Plotting.py


# TODO Change program icons
PORT_NUMBER = 5000
SIZE = 1024
hostName = gethostbyname( '0.0.0.0' )

mySocket = socket( AF_INET, SOCK_DGRAM )
mySocket.bind( (hostName, PORT_NUMBER) )


app = QtGui.QApplication([])

win = pg.GraphicsWindow(title="Waterloop Dashboard")
win.resize(1000,600)
win.setWindowTitle('Waterloop Dashboard')

# Enable antialiasing for prettier plots
pg.setConfigOptions(antialias=True)

p1 = win.addPlot(title="<h1> Levitation Distance </h1>")
curve1 = p1.plot(pen=(255,0,0))
p1.enableAutoRange('xy', True)  # Keep auto-scrolling and size adjustments


p2 = win.addPlot(title="<h1> Pressure Regulator Feedback </h1>")
curve2 = p2.plot(pen=(0,255,0))
p1.enableAutoRange('xy', True)

'''
p3 = win.addPlot(title="<h1> Pressure Sensor </h1>")
curve3 = p3.plot(pen=(0,0,255))
p3.enableAutoRange('xy', True)
'''

array_size = 500
distance_vals = np.zeros(array_size)

dpr_vals = np.zeros(array_size)
pressure_vals = np.zeros(array_size)

def update():
    global curve1, curve2, curve3, distance_vals, dpr_vals, pressure_vals

    (data,addr) = mySocket.recvfrom(SIZE)
    print(data)

    val = 0

    # Parse a value from the string
    val = ""
    position = 1
    while chr(data[position]) != '\r':
        val += chr(data[position])
        position+=1

    val = int(val)


    print(val)
    print(chr(data[0]))

    # Send to the correct graph
    # Distance sensor
    if chr(data[0]) == 'd':
        distance_vals = np.roll(distance_vals, -1)
        distance_vals[array_size - 1] = val
        curve1.setData(distance_vals)
    # DRP value
    elif chr(data[0]) == 'r':
        dpr_vals = np.roll(dpr_vals, -1)
        dpr_vals[array_size - 1] = val
        curve2.setData(dpr_vals)
    # Pressure sensor
    elif chr(data[0]) == 'p':
        pass
        '''
        pressure_vals = np.roll(pressure_vals, -1)
        pressure_vals[array_size - 1] = val
        curve3.setData(pressure_vals)
        '''


# Run update every 30ms
timer = QtCore.QTimer()
timer.timeout.connect(update)
timer.start(10) # Decrease this if more performance issues


win.nextRow()

test = False
## Start Qt event loop unless running in interactive mode or using pyside.
if __name__ == '__main__' and not test:
    if (sys.flags.interactive != 1) or not hasattr(QtCore, 'PYQT_VERSION'):
        QtGui.QApplication.instance().exec_()
        test = True


