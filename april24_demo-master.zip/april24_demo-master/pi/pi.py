# Code to run on the rpi on the pod, with the arduino connected via usb

import serial
from socket import socket, AF_INET, SOCK_DGRAM
import time

# The serial device may vary depending on how the pi is connected to the arduino
arduinoSerial = serial.Serial('/dev/ttyACM0', 9600)

SERVER_IP   = '192.168.1.148' # Change this depending on the network and server machine being used
PORT_NUMBER = 5000
SIZE = 1024
print ("Test client sending packets to IP {0}, via port {1}\n".format(SERVER_IP, PORT_NUMBER))

mySocket = socket( AF_INET, SOCK_DGRAM )

# Reads in values over serial, sends via network socket connection to server
while True:
        line = arduinoSerial.readline()
        mySocket.sendto(line,(SERVER_IP,PORT_NUMBER))
        print(line)
