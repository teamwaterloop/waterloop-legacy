This file is here only so that Git can keep track of the `lib` folder. If not it is saddly ignored by the system and who in the world would want something so sad to happen?

You can write messages to your loved ones here.

Peace.

