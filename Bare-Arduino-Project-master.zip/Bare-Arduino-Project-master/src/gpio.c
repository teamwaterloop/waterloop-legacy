#include "gpio.h"

int ssomething = 10;

void setup()
{
	printf("%d", something);
	int s = 5;
}

void loop() 
{

}
