#define NICE 10

int something = 5;
