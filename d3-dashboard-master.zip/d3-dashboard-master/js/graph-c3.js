var imuChart = c3.generate({
  bindto: "#imu-chart",
  data: {
    x: 'time',
    columns: [
      ['time'],
      ['x'],
      ['y'],
      ['z']
    ]
  },
  axis: {
    x: {
      type: 'timeseries',
      tick: {
        format: function(x) {
          function padTo(n, k){
            n = '' + n;
            while(k > n.length)
              n = '0' + n;
            return n;
          }
          var hr = x.getSeconds();
          var min = padTo(x.getMinutes(), 2);
          var sec = padTo(x.getSeconds(), 2);
          var millis = padTo(x.getMilliseconds(), 3);
          return hr + ':' + min + ':' + sec + '.' + millis;
        }
      }
    }
  }
});

listen('imu', function(data){
  imuChart.pointCount = (imuChart.pointCount || 0) + 1;
  imuChart.flow({
    columns: [
      ['time', data.ts],
      ['x', data.x],
      ['y', data.y],
      ['z', data.z]
    ],
    duration: 0,
    length: imuChart.pointCount > 10 ? 1 : 0
  });
});
