# Master Control Arduino
This is the main repository for all code running on the Arduino Mega and Ethernet 
Shield, which will be mounted to the pod.

# File Structure
There are two main directories to be concerned with:

- src/
- lib/

For the moment, src/ contains solely Main.cpp, which is the controlling code 
that gets run on startup. Otherwise, all code lives in lib/.

To be able to compile properly, every separate module (that is, .h and .cpp file) 
must be in a separate, aptly-named directory inside the lib/ folder.

The general idea is that functionality for the pod is modularized into different
libraries and referenced from src/.

# Contributing
To contribute code to this repository, you'll need to commit to a separate branch
and create a merge request; no code should ever be directly pushed to master.