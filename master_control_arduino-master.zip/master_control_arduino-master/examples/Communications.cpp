#include <Arduino.h>
#include <Wire.h>
#include "UdpComm.h"

void setup() {
	Serial.begin(115200);
	delay(1000);
}

void loop() {
	Serial.println("Hello world");
	delay(200);
	if(UdpComm::getInst()->checkUdp(true)) {
            Serial.println("Got packet!");
            UdpComm::getInst()->sendUdp("sup", 4);
        }
}

