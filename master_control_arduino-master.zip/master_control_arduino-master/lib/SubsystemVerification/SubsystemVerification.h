#ifndef _SUBSYSTEM_VERIFICATION_H
#define _SUBSYSTEM_VERIFICATION_H

class SubsystemVerification {
    public:
        static void RunPrelaunchVerification();
};

#endif // _SUBSYSTEM_VERIFICATION_H
