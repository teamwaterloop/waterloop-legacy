#ifndef _EMERGENCY_STOP_H
#define _EMERGENCY_STOP_H

class EmergencyStop {
    public:
        static void ExecuteEmergencyStop();
};

#endif // _EMERGENCY_STOP_H
