#include <Arduino.h>

#include <SPI.h>
#include <Ethernet.h>
#include <EthernetUdp.h>

#include "UdpComm.h"

/**
 * @file UdpComm.cpp
 * @author Jerry Wang
 * @version 1.0
 */

UdpComm* UdpComm::m_inst = NULL;

UdpComm::UdpComm()
    // IP address of recipient
    : m_ip(192, 168, 0, 116) {
    Ethernet.begin(m_mac, m_ip);
    m_Udp.begin(m_port);
}

UdpComm* UdpComm::getInst() {
    if(m_inst == NULL) {
        m_inst = new UdpComm();
    }
    return m_inst;
}

bool UdpComm::sendUdp(const char* msg, size_t size) {
    if(size > UDP_PACKET_MAX_SIZE) {
        if(Serial) {
            Serial.println("UDP Message size exceeds max packet size");
        }
        return false;
    }
    char tmp[UDP_PACKET_MAX_SIZE];
    strcpy(tmp, msg);

    m_Udp.beginPacket(m_Udp.remoteIP(), m_Udp.remotePort());
    m_Udp.write(tmp);
    m_Udp.endPacket();
    return true;
}

bool UdpComm::checkUdp(bool noisy) {
    int packetSize = m_Udp.parsePacket();
    if(packetSize) {
        m_Udp.read(packetBuffer, UDP_PACKET_MAX_SIZE);

        if(noisy && Serial) {
            Serial.print("Received packet of size ");
            Serial.println(packetSize);

            // Print the IP of the sender (remote)
            Serial.print("From ");
            IPAddress remote = m_Udp.remoteIP();
            printIP(remote);

            // Prints the port of the sender (remote)
            Serial.print(", port ");
            Serial.println(m_Udp.remotePort());

            // Print the contents of the buffer
            Serial.println("Contents:");
            Serial.println(packetBuffer);
        }
        return true;
    }
    return false;
}

void UdpComm::printIP(IPAddress ip) {
    if(Serial) {
        for (int i = 0; i < 4; i++) {
            Serial.print(ip[i], DEC);
            if (i < 3) {
                Serial.print(".");
            }
        }
    }
}
