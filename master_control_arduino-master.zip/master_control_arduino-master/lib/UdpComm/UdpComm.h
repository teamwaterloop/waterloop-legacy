#ifndef _UDP_COMM_H_
#define _UDP_COMM_H_

/**
 * @file UdpComm.h
 * @author Jerry Wang
 * @version 1.0
 */

#include <Arduino.h>
#include <Wire.h>
#include <SPI.h>
#include <Ethernet.h>
#include <EthernetUdp.h>         // UDP library from: bjoern@cs.stanford.edu 12/30/2008

#define UDP_PACKET_MAX_SIZE 64

class UdpComm {

        public:

            // Gets the instance of the singleton
            static UdpComm* getInst();

            // Member functions
            bool sendUdp(const char* msg, size_t size);
            bool checkUdp(bool noisy = false);

        private:

            // Private constructor for singleton
            UdpComm();

            // Member functions
            void printIP(IPAddress ip);

            // Static member variables
            static UdpComm* m_inst;

            // Member variables
            EthernetUDP m_Udp;
            byte m_mac[6] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED};
            char packetBuffer[UDP_PACKET_MAX_SIZE]; // buffer to hold incoming packet
            // Constants
            const IPAddress m_ip;
            const int m_port = 8000;
};

#endif // _UDP_COMM_H
