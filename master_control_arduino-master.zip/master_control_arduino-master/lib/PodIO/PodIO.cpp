#include "PodIO.h"
#include <Arduino.h>
#include "PinConstants.h"

void PodIO::InitializePins() {
    pinMode(ecTempPin, INPUT);
}

uint16_t PodIO::GetDigitalInput(uint16_t pinNo) {
   return digitalRead(pinNo); 
}

uint16_t PodIO::GetAnalogInput(uint16_t pinNo) {
    return analogRead(pinNo);
}

void PodIO::SetAnalogOutput(uint16_t pinNo, uint16_t data) {
    analogWrite(pinNo, data);
}

void PodIO::SetDigitalOutput(uint16_t pinNo, uint16_t data) {
    digitalWrite(pinNo, data);
}
