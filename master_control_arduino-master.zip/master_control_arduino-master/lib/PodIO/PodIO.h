#ifndef _POD_IO_H
#define _POD_IO_H

#include <inttypes.h>

class PodIO {
    private:
        static uint16_t GetDigitalInput(uint16_t pinNo);
        static uint16_t GetAnalogInput(uint16_t pinNo);

        static void SetDigitalOutput(uint16_t pinNo, uint16_t value);
        static void SetAnalogOutput(uint16_t pinNo, uint16_t value);
    public:
    	static void InitializePins();
        static uint16_t GetECBrakeTemperature();

};

#endif // _POD_IO_H
