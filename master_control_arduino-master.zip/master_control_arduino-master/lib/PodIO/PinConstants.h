#ifndef _PIN_CONSTANTS_H
#define _PIN_CONSTANTS_H

const int ecTempPin = 13;

#endif // _PIN_CONSTANTS_H
