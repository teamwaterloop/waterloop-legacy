#ifndef _ECBRAKES_H
#define _ECBRAKES_H

class ECBrakes {
    public:
        ECBrakes();
};

#endif // _ECBRAKES_H
