#ifndef _LOGGER_H
#define _LOGGER_H

#include <Arduino.h>
#include <SPI.h>
#include <SD.h>


class Logger {
    private:
        const int m_chipSelect = 4;
        bool m_initPassed = false;
        static Logger* m_inst;
        void InitializeSD();
        Logger();

    public:
        static Logger* GetInst();
        
        void Log(String data);
};

#endif // _LOGGER_H
