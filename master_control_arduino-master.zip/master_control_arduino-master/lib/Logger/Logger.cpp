#include "Logger.h"

Logger* Logger::m_inst = NULL;

Logger::Logger() {
    Logger::InitializeSD();
}

void Logger::InitializeSD() {
    if(!SD.begin(m_chipSelect)) {
        Serial.println("SD Card initialization failed.");
        return;
    }
    else {
        m_initPassed = true;
    }
}

Logger* Logger::GetInst() {
    if(m_inst == NULL) {
        m_inst = new Logger();
    }
    return m_inst;
}

void Logger::Log(String data) {
    if(m_initPassed) {
        File dataFile = SD.open("podlog.txt", FILE_WRITE);
        if (dataFile) {
            dataFile.println(data);
            dataFile.close();
        }
    }
    else {
        Logger::InitializeSD();    
    }
}
