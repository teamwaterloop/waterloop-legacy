#include <Arduino.h>
#include "UdpComm.h"
#include "PodIO.h"
#include "Logger.h"
#include "ECBrakes.h"
#include "SubsystemVerification.h"

void setup() {
	Serial.begin(115200);
	delay(1000);
}

void loop() {
	int s = 5;
	Serial.println("hello world");
	Logger* log = Logger::GetInst();
	log->Log("hello");
} 
