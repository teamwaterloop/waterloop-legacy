var PORT = 9000;
var HOST = '127.0.0.1';
var PORT1 = 8000;
var HOST1 = '192.168.0.116';

var dgram = require('dgram');
var server = dgram.createSocket('udp4');
var message = new Buffer('My KungFu is Good!');

server.send(message, 0, message.length, PORT1, HOST1, function(err, bytes) {
    if (err) throw err;
    console.log('UDP message sent to ' + HOST1 +':'+ PORT1);
});

server.on('listening', function () {
    var address = server.address();
    console.log('UDP Server listening on ' + address.address + ":" + address.port);
});

server.on('message', function (message, remote) {
    console.log(remote.address + ':' + remote.port +' - ' + message);
    server.close();

});

//server.bind(PORT, HOST);

