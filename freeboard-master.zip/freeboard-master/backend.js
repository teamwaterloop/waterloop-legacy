const express = require("express");

let app = express();
let server = require('http').createServer(app);
let io = require('socket.io')(server);

app.use(express.static(__dirname));

app.get('/', function(req, res){
  res.sendFile('index.html', {root: __dirname});
});

io.on('connection', function(client){
  console.log('Client connected!');
  setInterval(function(){
    client.emit('imu', {x: Math.random(), y: Math.random(), z: Math.random()});
  }, 1000);
  client.on('disconnect', function(){
    console.log('Client disconnected!');
  });
});

let PORT = process.env.PORT || 80;
server.listen(PORT, function(){
  console.log(`listening :${PORT}`);
  console.log(`Now, navigate to http://localhost:${PORT}/#source=dashboard.json`);
});
