freeboard dashboard
===================

Team Waterloop

How to run
----------
```
> npm install
> node backend.js
```
