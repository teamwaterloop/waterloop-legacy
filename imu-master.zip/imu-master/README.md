# IMU Sensor Subsystem

This subsystem controls all the IMU sensors on the pod. Each sensor contains three types of sub sensors.
These sub sensors are `GyroScope`, `Accelerometer` and `Magnetometer`. The data gathered from each sensor is in JSON format.

Example JSON data returned:

```C++
// This contains data from all the sensors 
{"Time Millis":1009,"Gyroscope":{"x":-1.54875,"y":12.19750,"z":11.36625},"Accelerometer":{"x":-0.02300,"y":-0.02300,"z":-0.02300},"Magnetometer":{"x":0.41986,"y":0.41986,"z":0.41986}}

// This contains data from only Gyroscope
{"Time Millis":1009,"Gyroscope":{"x":-1.54875,"y":12.19750,"z":11.36625}}

// This contains data from only Accelerometer
{"Time Millis":1009,"Accelerometer":{"x":-0.02300,"y":-0.02300,"z":-0.02300}}

// This contains data from only Magnetometer
{"Time Millis":1009,"Magnetometer":{"x":0.41986,"y":0.41986,"z":0.41986}}
```

More about data recieved is mentioned later on.

## How to Use

This subsystem is controlled by `IMUSubsytem` class. An Object must be created of this class to gather data from all the sensor. To create an object, you have to pass in a parameter to specify how many imu sensors are on the pod

```C++
IMUSubsystem imu(2);            // creates subsystem with 2 imu sensors
```

Before recording any sensor values, we have to check if all the imu sensors are working. To do this, call `sensors_working` method and it will return true to signal the working of all the sensors and false even if one sensor is not working

```C++
if (imu.sensors_working()){}    // success
else{}                          // failure
```

### Overview of functions to gather data
Each component of IMU sensor returns x, y and z values. Since the data is formatted in JSON format, the data recieved by any function call includes x, y and z for that perticular sensor. JSON data also includes a time in milliseconds. This time is the time elapsed since the arduino has started working.

To get data from all the sensors in the subsystem, a call can be made to `JSON_sensor_data`. This method has two variations. The data recieved from any variation is an array of JSON strings. You have to `delete` this array yourself after you are done using it. If not deleted, there will be memory leaks. Number of strings in the array are the number of sensors in the subsystem.


To get data for all sensors and for each component of each sensor, see the code below. 
```C++
imu.JSON_sensor_data();         // pass without any parameter
```	

To get data for all sensors but only for certain component of each sensor, see the code below.

```C++
imu.JSON_sensor_data(GYRO);     // data for Gyroscope only
imu.JSON_sensor_data(ACCEL);    // data for Accelerometer only
imu.JSON_sensor_data(MAG);      // data for Magnetometer only
```	

If for some reason read fails for any component of any sensor, the output for that component will be `-99999.00000` for x, y and z axis. Example of such data is below:

```C++
// In this data, Gyroscope read failed but the read was successful for all other components
{"Time Millis":1039,"Gyroscope":{"x":-99999.00000,"y":-99999.00000,"z":-99999.00000},"Accelerometer":{"x":-0.02300,"y":-0.02300,"z":-0.02300},"Magnetometer":{"x":0.41986,"y":0.41986,"z":0.41986}}
```

Since the value of any sensor component will never be `-99999.00000`, we can detect failure and take actions accordingly.

To get the number of sensors in the subsystem, call the method `get_sensor_total`. 

```C++
imu.get_sensor_total();         // will return 2 based on our declaration of the object above
```
Now that above functions return values for Serial communications, we may need values in float format so that our pod can utilize them.
In order to do that, there are following functions:
 
```C++
imu.getX(0, GYRO);                 // x data for Gyroscope and from sensor 0
imu.getY(1, ACCEL);                // y data for Accelerometer and from sensor 1
imu.getZ(1, MAG);                  // z data for Magnetometer and from sensor 1
```

Hence, you can get x, y and z values from any imu sensor and for every component.


## Documentation of IMUSensor class used by IMUSubsystem class

`IMUSensor` class is used by IMUSubsystem to make everything work. A client can choose to use `IMUSensor` class if he/she wishes to do so. Keep in mind this class only supports one IMU sensor and does not return data in JSON format. But, this class can be modified to change the functionality of each components for IMU sensor. These changes will also show up on `IMUSubsystem`.

Create an object of this class.

```C++
IMUSensor sensor;
```	

If you are not satisfied by how `Gyroscope` or `Accelerometer` or `Magnetometer` component works and outputs data, you can change  the settings of each component using `setup` methods. These methods have default values so you do not have to specify every parameter.

```C++
// setupGyro() specifies the settings for the gyroscope.
// * scale sets the full-scale range of the gyroscope. scale can be set to either 245, 500, or 2000
// * sampleRatesets the output data rate (ODR) of the gyro
//   sampleRate can be set between 1-6
// 	 1 = 14.9    4 = 238
//   2 = 59.5    5 = 476
//   3 = 119     6 = 952
// * flipX, flipY, and flipZ are booleans that can automatically switch the positive/negative
//   orientation of the three gyro axes.
void setupGyro(int scale=245, int sampleRate=3, bool flipX=false, bool flipY=false, bool flipZ=false);

// setupAccel() specifies the settings for the accelerometer.
// * scale sets the full-scale range of accelerometer. The scale can be 2, 4, 8 or 16
// * sampleRate sets the output data rate of the accelerometer. If Gyroscope is running,
//   the sample rate is same as gyroscope. Same rate can be be 1-6:
//   1 = 10 Hz    4 = 238 Hz
//   2 = 50 Hz    5 = 476 Hz
//   3 = 119 Hz   6 = 952 Hz
void setupAccel(int scale=8, int sampleRate=1);

// setupMag() specifies the settings for the magnetometer.
// * scale sets the full-scale range of the magnetometer. Mag scale can be 4, 8, 12, or 16
// * sampleRate sets the output data rate (ODR) of the magnetometer.
//   mag data rate can be 0-7:
//   0 = 0.625 Hz  4 = 10 Hz
//   1 = 1.25 Hz   5 = 20 Hz
//   2 = 2.5 Hz    6 = 40 Hz
//   3 = 5 Hz      7 = 80 Hz
// * tempComp enables or disables temperature compensation of the magnetometer.
// * operatingMode sets the operating mode of the magnetometer. operatingMode can be 0-2:
//   0 = continuous conversion
//   1 = single-conversion
//   2 = power down
void setupMag(int scale=12, int sampleRate=5, bool tempComp=false, int operatingMode=0);
```	

You can get data from each data component of the sensor by using `get` methods. Before getting these x, y and z values, you have to read the sensor

To read the sensor, use the `read` method. This method returns true if the read was successful and false if it was unsuccessful.

```C++
read(GYRO);       // read GYRO
read(ACCEL);      // reada ACCEL
read(MAG);        // read MAG
```

After the read is successful, you can go ahead and get data from that component. Data accquired from each component is of type `float` and it is precise to `5 decimal points`.

```C++
// X values
getX(GYRO);       // GYRO X Value
getX(ACCEL);      // ACCEL X Value
getX(MAG);        // MAG X Value

// Y values
getY(GYRO);       // GYRO Y Value
getY(ACCEL);      // ACCEL Y Value
getY(MAG);        // MAG Y Value

// Z values
getZ(GYRO);       // GYRO Z Value
getZ(ACCEL);      // ACCEL Z Value
getZ(MAG);        // MAG Z Value
```