/*
 * IMUSubsystem.h
 *
 *  Created on: May 27, 2017
 *  Author: Deep
 *  Description: IMUSubsystem holds number of IMU sensors' objects and transfer data from them in JSON format
 */

#ifndef SRC_IMUSUBSYSTEM_H_
#define SRC_IMUSUBSYSTEM_H_

#include "imu_subsystem_files/IMUSensor.h"
#include "imu_subsystem_files/IMUData.h"

class IMU_Subsystem {
private:
    const int sensor_total;
    IMUSensor **imus;

    // default values for x, y and z when sensor component stops working
    const long stop_value = -99999;

    IMUData data;

public:
    IMU_Subsystem(int num_sensors);

    ~IMU_Subsystem();

    // sensor_working() returns true if all sensors are working and false otherwise
    bool sensors_working();

    // JSON_sensor_data() returns an array of all sensors data formatted in JSON data
    // client has to dispose the memory when done
    String JSON_sensor_data(int sensor);

    // JSON_sensor_data() returns data from the component for all sensors
    // client has to dispose the memory when done
    String JSON_sensor_data(int sesnor, int component);

    // getSensorTotal() returns the number of sensors in the subsystem
    int get_sensor_total();

    // getX() returns the x value of the component from the particular system
    float getX(int system, int component);

    // getY() returns the y value of the component from the particular system
    float getY(int system, int component);

    // getZ() returns the z value of the component from the particular system
    float getZ(int system, int component);
};

#endif
