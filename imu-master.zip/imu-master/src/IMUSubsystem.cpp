/*
 * IMUSubsystem.cpp
 *
 *  Created on: May 27, 2017
 *  Author: Deep
 *  Description: Implementation of IMUSubsystem class
 */

#include "IMUSubsystem.h"

IMU_Subsystem::IMU_Subsystem(int num_sensors) : sensor_total{num_sensors} {
    imus = new IMUSensor *[sensor_total];

    for (int i = 0; i < sensor_total; i++) {
        imus[i] = new IMUSensor();
    }
}

IMU_Subsystem::~IMU_Subsystem() {
    for (int i = 0; i < sensor_total; i++) {
        delete imus[i];
    }

    delete[] imus;
}

bool IMU_Subsystem::sensors_working() {
    for (int i = 0; i < sensor_total; i++) {
        if (!imus[i]->isStarted()) return false;
    }

    return true;
}

String IMU_Subsystem::JSON_sensor_data(int sensor) {
    float gyro_data[3];
    float accel_data[3];
    float mag_data[3];

    // read sensor and store values
    if (imus[sensor]->read(GYRO)) {
        gyro_data[0] = imus[sensor]->getX(GYRO);
        gyro_data[1] = imus[sensor]->getY(GYRO);
        gyro_data[2] = imus[sensor]->getZ(GYRO);
    } else {
        gyro_data[0] = stop_value;
        gyro_data[1] = stop_value;
        gyro_data[2] = stop_value;
    }

    if (imus[sensor]->read(ACCEL)) {
        accel_data[0] = imus[sensor]->getX(ACCEL);
        accel_data[1] = imus[sensor]->getY(ACCEL);
        accel_data[2] = imus[sensor]->getZ(ACCEL);
    } else {
        accel_data[0] = stop_value;
        accel_data[1] = stop_value;
        accel_data[2] = stop_value;
    }

    if (imus[sensor]->read(MAG)) {
        mag_data[0] = imus[sensor]->getX(MAG);
        mag_data[1] = imus[sensor]->getY(MAG);
        mag_data[2] = imus[sensor]->getZ(MAG);
    } else {
        mag_data[0] = stop_value;
        mag_data[1] = stop_value;
        mag_data[2] = stop_value;
    }

    String json_string = data.createIMUString(gyro_data, accel_data, mag_data);

    return json_string;
}


int IMU_Subsystem::get_sensor_total() {
    return sensor_total;
}

float IMU_Subsystem::getX(int system, int component) {
    if (imus[system]->read(component)) {
        return imus[system]->getX(component);
    } else
        return stop_value;
}

float IMU_Subsystem::getY(int system, int component) {
    if (imus[system]->read(component)) {
        return imus[system]->getY(component);
    } else
        return stop_value;
}

float IMU_Subsystem::getZ(int system, int component) {
    if (imus[system]->read(component)) {
        return imus[system]->getZ(component);
    } else
        return stop_value;
}