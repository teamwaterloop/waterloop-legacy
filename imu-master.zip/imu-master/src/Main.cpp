#include <Arduino.h>
#include "imu_subsystem_files/IMUSensor.h"
#include "IMUSubsystem.h"

// create a subsystem of 1 sensors
IMU_Subsystem is(1);

void setup() {
    Serial.begin(115200);
    delay(1000);


    if (is.sensors_working()) {
        Serial.println("All sensors working");
    } else {
        Serial.println("Not working");
        Serial.println("Infinite loop");
        while (1){

        }
    }

    /*
    String *data = is.JSON_sensor_data();

    for (int i = 0; i < is.get_sensor_total(); ++i) {
        Serial.print("Data for Sensor ");
        Serial.print(i);
        Serial.println(" ");
        Serial.println(data[i]);
        Serial.println("");
    }
    delete (data);*/
}


void loop() {
    delay(500);
    String data = is.JSON_sensor_data(0);
    Serial.println(data);
}
