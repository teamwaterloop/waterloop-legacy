/*
 * IMUData.h
 *
 *  Created on: May 25, 2017
 *  Author: Deep Dhillon
 *  Description: IMUData uses data from IMU sensor and converts it into JSON
 */

#ifndef SRC_IMUDATA_H_
#define SRC_IMUDATA_H_

#include "ArduinoJson.h"
#include "IMUSensor.h"

class IMUData {
public:
    // createJsonData() creates JSON data using data from all sensor components
    void printSensorString(String sensor_name, float &sensor_data[], int num_data);
};

#endif
