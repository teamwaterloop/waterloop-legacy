This is the master code for the Waterloop Pod

Some things to note:

-If you are doing work using a specific library accesors and mutators have 
already been written.

-Do not attempt to change the HAL_ libraries as something will very likely go
wrong.

-If you want to add functionality in terms of pins, pass it by Aakash Mali
    - i.e. If you wrote code for SPI, and the pin numbers are different, change
        your pin numbers, do not attempt to change it using the cube.
        
-if you are unsure about something contact Aakash Mali (on fleep please)

-If you are working with interupts;
    REMEMBER: NO FUNCTION CALLS WITHIN THE CALLBACK FUNCTION -> this includes
    printf.
    - Interupts are meant to set flags.
    
-Avoid recursion

-If the process is very computationaly heavy, see if it can be broken down into 
smaller steps that can occur over several interations

Ensure that your code is well commented AND has a relevant name.


