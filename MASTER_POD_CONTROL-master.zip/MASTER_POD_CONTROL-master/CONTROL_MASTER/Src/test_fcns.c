#include "gpio.h"

/* PRELIMINARY TESTS : SUBSYSTEM COMPONENTS */

void pre_test_frict(void){
	GPIO_frict_init();
	GPIO_frict_actuate_enable();
	GPIO_frict_actuate_disable();

	// signal test complete
}

void pre_test_drive(void){
	GPIO_drive_init();
	HAL_Delay(5000);

	// lower drive then lift drive
	GPIO_drive_actuate_enable();
	GPIO_drive_actuate_disable();

	// TEST MOTOR WHILE DRIVE IS UP
	GPIO_drive_motor_forward();
	HAL_Delay(10000); // Drive for 10s
	GPIO_drive_motor_stop();
	HAL_Delay(10000); // WAIT FOR MOTOR TO STOP
	GPIO_drive_motor_backward();
	HAL_Delay(10000); // DRIVE FOR 10s
	GPIO_drive_motor_stop();

	// signal test finish/pass
}


/* TEST RUNS */
void test_run_drive(void){
	GPIO_drive_actuate_enable();
	GPIO_drive_motor_forward();
	HAL_Delay(10000);
	GPIO_drive_motor_stop();
	HAL_Delay(5000);
	GPIO_drive_motor_backward();
	HAL_Delay(10000);
	GPIO_drive_motor_stop();

	// signal test finish/pass
}


/* useful functions */
void activate_frict_brakes(void){
	GPIO_frict_actuate_enable();
}

void deactivate_frict_brakes(void){
	GPIO_frict_actuate_disable();
}
