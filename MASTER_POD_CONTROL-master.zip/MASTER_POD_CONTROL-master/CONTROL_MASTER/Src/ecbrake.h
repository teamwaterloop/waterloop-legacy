#ifndef ECBRAKE_H
#define ECBRAKE_H

#include "stm32f7xx.h"
#include "stm32f7xx_hal.h"
#include "stm32f7xx_hal_adc.h"
#include "stm32f7xx_hal_gpio.h"
#include "stm32f7xx_hal_tim.h"


typedef struct EC_brake_instance{
	GPIO_TypeDef* temp_gpiox;
	uint16_t temp_gpio_pin;
	TIM_HandleTypeDef* ec_brake_actuator;
	
	//info on current/recent conditions	
}Ec_brake_instance_t;



//call this function in the setup code so ecbrake has access to the HAL structs it requires
/*
* param: actuator_tim_handle - pointer to the pwm handler for the actuator
* dig_temp_gpiox - pointer to the GPIO_TypeDef for the GPIO line that temperature digital pin is on (e.g. gpioa, gpiob, etc)
* dig_temp_pin - digital temperature pin number
*
*/
void ecBrake_init(TIM_HandleTypeDef* actuator_tim_handle, GPIO_TypeDef* dig_temp_gpiox,uint16_t dig_temp_pin);


//call when ec brake action is needed
/*
* param: veleocity - current velocity
* param: acceleration - current acceleration
* tempAdcValues - array of all analog temp pin readings (may end up being just 1)
* distance_adc_values - array of the 3 distance sensor readings
* 
*/
int ecBrake_main(int velocity, int acceleration,int* tempAdcValues, int* distance_adc_values);


#endif
