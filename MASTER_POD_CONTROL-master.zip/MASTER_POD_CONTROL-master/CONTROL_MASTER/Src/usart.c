/**
  ******************************************************************************
  * File Name          : USART.c
  * Description        : This file provides code for the configuration
  *                      of the USART instances.
  ******************************************************************************
  *
  * COPYRIGHT(c) 2016 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "usart.h"

#include "gpio.h"
#include "dma.h"

/* USER CODE BEGIN 0 */
#include "adc.h"
#include <stdlib.h>
#include <string.h>

#define UART_BUFFER_LENGTH 2

uint8_t uart_dmaBuffer[UART_BUFFER_LENGTH]; 
uint8_t uart_dataBuffer[UART_BUFFER_LENGTH];
/* USER CODE END 0 */

UART_HandleTypeDef huart8;
DMA_HandleTypeDef hdma_uart8_rx;

/* UART8 init function */
void MX_UART8_Init(void)
{

  huart8.Instance = UART8;
  huart8.Init.BaudRate = 115200;
  huart8.Init.WordLength = UART_WORDLENGTH_8B;
  huart8.Init.StopBits = UART_STOPBITS_1;
  huart8.Init.Parity = UART_PARITY_NONE;
  huart8.Init.Mode = UART_MODE_TX_RX;
  huart8.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart8.Init.OverSampling = UART_OVERSAMPLING_16;
  huart8.Init.OneBitSampling = UART_ONEBIT_SAMPLING_DISABLED ;
  huart8.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  HAL_UART_Init(&huart8);

}

void HAL_UART_MspInit(UART_HandleTypeDef* huart)
{

  GPIO_InitTypeDef GPIO_InitStruct;
  if(huart->Instance==UART8)
  {
  /* USER CODE BEGIN UART8_MspInit 0 */

  /* USER CODE END UART8_MspInit 0 */
    /* Peripheral clock enable */
    __UART8_CLK_ENABLE();
  
    /**UART8 GPIO Configuration    
    PE0     ------> UART8_RX
    PE1     ------> UART8_TX 
    */
    GPIO_InitStruct.Pin = UART8_RPI_RX_Pin|UART8_RPI_TX_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF8_UART8;
    HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

    /* Peripheral DMA init*/
  
    hdma_uart8_rx.Instance = DMA1_Stream6;
    hdma_uart8_rx.Init.Channel = DMA_CHANNEL_5;
    hdma_uart8_rx.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_uart8_rx.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_uart8_rx.Init.MemInc = DMA_MINC_ENABLE;
    hdma_uart8_rx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
    hdma_uart8_rx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
    hdma_uart8_rx.Init.Mode = DMA_CIRCULAR;
    hdma_uart8_rx.Init.Priority = DMA_PRIORITY_LOW;
    hdma_uart8_rx.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    HAL_DMA_Init(&hdma_uart8_rx);

    __HAL_LINKDMA(huart,hdmarx,hdma_uart8_rx);

  /* USER CODE BEGIN UART8_MspInit 1 */

  /* USER CODE END UART8_MspInit 1 */
  }
}

void HAL_UART_MspDeInit(UART_HandleTypeDef* huart)
{

  if(huart->Instance==UART8)
  {
  /* USER CODE BEGIN UART8_MspDeInit 0 */

  /* USER CODE END UART8_MspDeInit 0 */
    /* Peripheral clock disable */
    __UART8_CLK_DISABLE();
  
    /**UART8 GPIO Configuration    
    PE0     ------> UART8_RX
    PE1     ------> UART8_TX 
    */
    HAL_GPIO_DeInit(GPIOE, UART8_RPI_RX_Pin|UART8_RPI_TX_Pin);

    /* Peripheral DMA DeInit*/
    HAL_DMA_DeInit(huart->hdmarx);
  }
  /* USER CODE BEGIN UART8_MspDeInit 1 */

  /* USER CODE END UART8_MspDeInit 1 */
} 

/* USER CODE BEGIN 1 */
TransmissionContract_t* TransmissionContract_live(){
		TransmissionContract_t* tc = malloc(sizeof(TransmissionContract_t));
		tc->levFrontLeftDpr = adc_lev_get_DPR_val(0);
		tc->levFrontRightDpr = adc_lev_get_DPR_val(1);
		tc->levBackLeftDpr = adc_lev_get_DPR_val(2);
		tc->levBackRightDpr = adc_lev_get_DPR_val(3);
		tc->levLowPressure = adc_lev_get_low_press_val();
		tc->levHighPressure = adc_lev_get_high_press_val();
		tc->levFrontLeftDistance = adc_lev_get_dist_val(0);
		tc->levFrontRightDistance = adc_lev_get_dist_val(1);
		tc->levBackLeftDistance = adc_lev_get_dist_val(2);
		tc->levBackRightDistance = adc_lev_get_dist_val(3);
		tc->ecXDistance = adc_EC_get_distX_val();
		tc->ecYDistance = adc_EC_get_distY_val();
		tc->latFrontDistance = adc_lat_get_front_dist_val();
		tc->batteryTemperature = adc_batt_get_temp_val();
		tc->batteryFirstVoltage = adc_batt_get_V1_val();
		tc->latBackDistance = adc_lat_get_back_dist_val();
		return tc;
}

void SendTransmissionContract() {
		TransmissionContract_t* tc = TransmissionContract_live();
		UART_Tx_Data_8B_Full('@');
		UART_Tx_Data_16B_Full(tc->levFrontLeftDpr);
		UART_Tx_Data_16B_Full(tc->levFrontRightDpr);
		UART_Tx_Data_16B_Full(tc->levBackLeftDpr);
		UART_Tx_Data_16B_Full(tc->levBackRightDpr);
		UART_Tx_Data_16B_Full(tc->levLowPressure);
		UART_Tx_Data_16B_Full(tc->levHighPressure);
		UART_Tx_Data_16B_Full(tc->levFrontLeftDistance);
		UART_Tx_Data_16B_Full(tc->levFrontRightDistance);
		UART_Tx_Data_16B_Full(tc->levBackLeftDistance);
		UART_Tx_Data_16B_Full(tc->levBackRightDistance);
		UART_Tx_Data_16B_Full(tc->ecXDistance);
		UART_Tx_Data_16B_Full(tc->ecYDistance);
		UART_Tx_Data_16B_Full(tc->latFrontDistance);
		UART_Tx_Data_16B_Full(tc->batteryTemperature);
		UART_Tx_Data_16B_Full(tc->batteryFirstVoltage);
		UART_Tx_Data_16B_Full(tc->latBackDistance);
		free(tc);
}

void UART_Tx_Data_helper(uint8_t *pData)
{
	HAL_UART_Transmit(&huart8, pData, sizeof(pData),0xFFFF);
}
void UART_Tx_Data_16B (uint8_t upper_byte, uint8_t lower_byte)
{
	uint8_t *temp;
	uint8_t temp_val = '@';
	temp = &temp_val;
	UART_Tx_Data_helper(temp);
	temp_val = upper_byte;
	UART_Tx_Data_helper(temp);
	temp_val = lower_byte;
	UART_Tx_Data_helper(temp);	
}

void UART_Tx_Data_16B_Full(uint16_t data)
{
	uint8_t *temp;
	uint8_t temp_val = 0;
	temp = &temp_val;
	temp_val = (data >> 8) & 0xFF;
	UART_Tx_Data_helper(temp);
	temp_val = data & 0xFF;
	UART_Tx_Data_helper(temp);
	temp_val = '\n';
	UART_Tx_Data_helper(temp);
	HAL_Delay(50);
}

void UART_Tx_Data_8B_Full(uint8_t data)
{
	uint8_t *temp;
	uint8_t temp_val = data;
	temp = &temp_val;
	UART_Tx_Data_helper(temp);
	HAL_Delay(20);
}

//This function returns 16Bits of information
uint16_t UART_Rx_Data_16B(void)
{
	uint16_t upper_data_rx = uart_dataBuffer[1] << 8;
	return upper_data_rx + uart_dataBuffer[0];
}

//This function recieves data from the comm line into a buffer.
void UART_get_rx_data_16B(void)
{
	HAL_UART_Receive_DMA(&huart8, uart_dmaBuffer, sizeof(uart_dmaBuffer));
}

//conversion complete calback function, transfers data from dma into memory.
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	memcpy (&uart_dataBuffer, &uart_dmaBuffer, sizeof(uart_dmaBuffer));
}
/* USER CODE END 1 */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
