/**
  ******************************************************************************
  * File Name          : ADC.c
  * Description        : This file provides code for the configuration
  *                      of the ADC instances.
  ******************************************************************************
  *
  * COPYRIGHT(c) 2016 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "adc.h"

#include "gpio.h"
#include "dma.h"

/* USER CODE BEGIN 0 */
#include <string.h>
#include <stdlib.h>

#define	ADC_SAMPLES_PER_CHANNEL	8
#define	ADC_1_MAX_CHANNELS 9
#define	ADC_2_MAX_CHANNELS 1
#define	ADC_3_MAX_CHANNELS 8
#define ADC_1_RAW_BUFFER_LENGTH (ADC_SAMPLES_PER_CHANNEL * ADC_1_MAX_CHANNELS)	
#define ADC_2_RAW_BUFFER_LENGTH (ADC_SAMPLES_PER_CHANNEL * ADC_2_MAX_CHANNELS)	
#define ADC_3_RAW_BUFFER_LENGTH (ADC_SAMPLES_PER_CHANNEL * ADC_3_MAX_CHANNELS)	

//Buffers for the conversion complete callback function.
uint16_t adc_1_dmaBuffer[ADC_1_RAW_BUFFER_LENGTH]; 
uint16_t adc_1_workingBuffer[ADC_1_RAW_BUFFER_LENGTH]; 
uint32_t adc_1_avgBuffer[ADC_1_MAX_CHANNELS];
uint16_t adc_1_dataBuffer[ADC_1_MAX_CHANNELS];

uint16_t adc_2_dmaBuffer[ADC_2_RAW_BUFFER_LENGTH]; 
uint16_t adc_2_workingBuffer[ADC_2_RAW_BUFFER_LENGTH]; 
uint32_t adc_2_avgBuffer[ADC_2_MAX_CHANNELS];
uint16_t adc_2_dataBuffer[ADC_2_MAX_CHANNELS];

uint16_t adc_3_dmaBuffer[ADC_3_RAW_BUFFER_LENGTH]; 
uint16_t adc_3_workingBuffer[ADC_3_RAW_BUFFER_LENGTH]; 
uint32_t adc_3_avgBuffer[ADC_3_MAX_CHANNELS];
uint16_t adc_3_dataBuffer[ADC_3_MAX_CHANNELS];

//Get function offsets/values
#define LEV_LOW_PRESS_REG_IDX 4
#define LEV_HIGH_PRESS_REG_IDX 5
#define EC_DIST_IDX_OFFSET 6
#define EC_TEMP_IDX 0
#define BATT_TEMP_IDX 0
#define LEV_DIST_IDX_OFFSET 1
#define BATT_V_IDX_OFFSET 5 
#define EC_ACTUATOR_IDX 7
#define LAT_DIST_BACK_IDX 6
#define EC_DIST_Y_IDX 7
#define EC_DIST_X_IDX 8
#define LAT_FRONT_DIST_IDX 5
#define BATT_V1_IDX 6

/* USER CODE END 0 */

ADC_HandleTypeDef hadc1;
ADC_HandleTypeDef hadc2;
ADC_HandleTypeDef hadc3;
DMA_HandleTypeDef hdma_adc1;
DMA_HandleTypeDef hdma_adc2;
DMA_HandleTypeDef hdma_adc3;

/* ADC1 init function */
void MX_ADC1_Init(void)
{
  ADC_ChannelConfTypeDef sConfig;

    /**Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion) 
    */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCKPRESCALER_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION12b;
  hadc1.Init.ScanConvMode = ENABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 9;
  hadc1.Init.DMAContinuousRequests = ENABLE;
  hadc1.Init.EOCSelection = EOC_SINGLE_CONV;
  HAL_ADC_Init(&hadc1);

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  HAL_ADC_ConfigChannel(&hadc1, &sConfig);

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_3;
  sConfig.Rank = 2;
  HAL_ADC_ConfigChannel(&hadc1, &sConfig);

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_4;
  sConfig.Rank = 3;
  HAL_ADC_ConfigChannel(&hadc1, &sConfig);

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_5;
  sConfig.Rank = 4;
  HAL_ADC_ConfigChannel(&hadc1, &sConfig);

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_6;
  sConfig.Rank = 5;
  HAL_ADC_ConfigChannel(&hadc1, &sConfig);

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_8;
  sConfig.Rank = 6;
  HAL_ADC_ConfigChannel(&hadc1, &sConfig);

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_9;
  sConfig.Rank = 7;
  HAL_ADC_ConfigChannel(&hadc1, &sConfig);

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_10;
  sConfig.Rank = 8;
  HAL_ADC_ConfigChannel(&hadc1, &sConfig);

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_12;
  sConfig.Rank = 9;
  HAL_ADC_ConfigChannel(&hadc1, &sConfig);

}
/* ADC2 init function */
void MX_ADC2_Init(void)
{
  ADC_ChannelConfTypeDef sConfig;

    /**Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion) 
    */
  hadc2.Instance = ADC2;
  hadc2.Init.ClockPrescaler = ADC_CLOCKPRESCALER_PCLK_DIV4;
  hadc2.Init.Resolution = ADC_RESOLUTION12b;
  hadc2.Init.ScanConvMode = ENABLE;
  hadc2.Init.ContinuousConvMode = ENABLE;
  hadc2.Init.DiscontinuousConvMode = DISABLE;
  hadc2.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc2.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc2.Init.NbrOfConversion = 1;
  hadc2.Init.DMAContinuousRequests = ENABLE;
  hadc2.Init.EOCSelection = EOC_SINGLE_CONV;
  HAL_ADC_Init(&hadc2);

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_13;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  HAL_ADC_ConfigChannel(&hadc2, &sConfig);

}
/* ADC3 init function */
void MX_ADC3_Init(void)
{
  ADC_ChannelConfTypeDef sConfig;

    /**Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion) 
    */
  hadc3.Instance = ADC3;
  hadc3.Init.ClockPrescaler = ADC_CLOCKPRESCALER_PCLK_DIV4;
  hadc3.Init.Resolution = ADC_RESOLUTION12b;
  hadc3.Init.ScanConvMode = ENABLE;
  hadc3.Init.ContinuousConvMode = ENABLE;
  hadc3.Init.DiscontinuousConvMode = DISABLE;
  hadc3.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc3.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc3.Init.NbrOfConversion = 8;
  hadc3.Init.DMAContinuousRequests = ENABLE;
  hadc3.Init.EOCSelection = EOC_SINGLE_CONV;
  HAL_ADC_Init(&hadc3);

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_4;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  HAL_ADC_ConfigChannel(&hadc3, &sConfig);

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_5;
  sConfig.Rank = 2;
  HAL_ADC_ConfigChannel(&hadc3, &sConfig);

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_6;
  sConfig.Rank = 3;
  HAL_ADC_ConfigChannel(&hadc3, &sConfig);

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_7;
  sConfig.Rank = 4;
  HAL_ADC_ConfigChannel(&hadc3, &sConfig);

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_8;
  sConfig.Rank = 5;
  HAL_ADC_ConfigChannel(&hadc3, &sConfig);

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_9;
  sConfig.Rank = 6;
  HAL_ADC_ConfigChannel(&hadc3, &sConfig);

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_14;
  sConfig.Rank = 7;
  HAL_ADC_ConfigChannel(&hadc3, &sConfig);

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_15;
  sConfig.Rank = 8;
  HAL_ADC_ConfigChannel(&hadc3, &sConfig);

}

void HAL_ADC_MspInit(ADC_HandleTypeDef* hadc)
{

  GPIO_InitTypeDef GPIO_InitStruct;
  if(hadc->Instance==ADC1)
  {
  /* USER CODE BEGIN ADC1_MspInit 0 */

  /* USER CODE END ADC1_MspInit 0 */
    /* Peripheral clock enable */
    __ADC1_CLK_ENABLE();
  
    /**ADC1 GPIO Configuration    
    PC0     ------> ADC1_IN10
    PC2     ------> ADC1_IN12
    PA0/WKUP     ------> ADC1_IN0
    PA3     ------> ADC1_IN3
    PA4     ------> ADC1_IN4
    PA5     ------> ADC1_IN5
    PA6     ------> ADC1_IN6
    PB0     ------> ADC1_IN8
    PB1     ------> ADC1_IN9 
    */
    GPIO_InitStruct.Pin = EC_DIST_Y_ADC_Pin|EC_DIST_X_ADC_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = LEV_DPR_FL_ADC_Pin|LEV_DPR_FR_ADC_Pin|LEV_DPR_BL_ADC_Pin|LEV_DPR_BR_ADC_Pin 
                          |LEV_LOW_PRESS_REG_ADC_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = LEV_HIGH_PRESS_REG_ADC_Pin|LAT_DIST_BACK_ADC_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* Peripheral DMA init*/
  
    hdma_adc1.Instance = DMA2_Stream0;
    hdma_adc1.Init.Channel = DMA_CHANNEL_0;
    hdma_adc1.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_adc1.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_adc1.Init.MemInc = DMA_MINC_ENABLE;
    hdma_adc1.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    hdma_adc1.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
    hdma_adc1.Init.Mode = DMA_CIRCULAR;
    hdma_adc1.Init.Priority = DMA_PRIORITY_LOW;
    hdma_adc1.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    HAL_DMA_Init(&hdma_adc1);

    __HAL_LINKDMA(hadc,DMA_Handle,hdma_adc1);

  /* USER CODE BEGIN ADC1_MspInit 1 */

  /* USER CODE END ADC1_MspInit 1 */
  }
  else if(hadc->Instance==ADC2)
  {
  /* USER CODE BEGIN ADC2_MspInit 0 */

  /* USER CODE END ADC2_MspInit 0 */
    /* Peripheral clock enable */
    __ADC2_CLK_ENABLE();
  
    /**ADC2 GPIO Configuration    
    PC3     ------> ADC2_IN13 
    */
    GPIO_InitStruct.Pin = EC_TEMP_1_ADC_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(EC_TEMP_1_ADC_GPIO_Port, &GPIO_InitStruct);

    /* Peripheral DMA init*/
  
    hdma_adc2.Instance = DMA2_Stream2;
    hdma_adc2.Init.Channel = DMA_CHANNEL_1;
    hdma_adc2.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_adc2.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_adc2.Init.MemInc = DMA_MINC_ENABLE;
    hdma_adc2.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    hdma_adc2.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
    hdma_adc2.Init.Mode = DMA_CIRCULAR;
    hdma_adc2.Init.Priority = DMA_PRIORITY_LOW;
    hdma_adc2.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    HAL_DMA_Init(&hdma_adc2);

    __HAL_LINKDMA(hadc,DMA_Handle,hdma_adc2);

  /* USER CODE BEGIN ADC2_MspInit 1 */

  /* USER CODE END ADC2_MspInit 1 */
  }
  else if(hadc->Instance==ADC3)
  {
  /* USER CODE BEGIN ADC3_MspInit 0 */

  /* USER CODE END ADC3_MspInit 0 */
    /* Peripheral clock enable */
    __ADC3_CLK_ENABLE();
  
    /**ADC3 GPIO Configuration    
    PF3     ------> ADC3_IN9
    PF4     ------> ADC3_IN14
    PF5     ------> ADC3_IN15
    PF6     ------> ADC3_IN4
    PF7     ------> ADC3_IN5
    PF8     ------> ADC3_IN6
    PF9     ------> ADC3_IN7
    PF10     ------> ADC3_IN8 
    */
    GPIO_InitStruct.Pin = LAT_DIST_FRONT_ADC_Pin|BATT_V1_ADC_Pin|EC_ACTUATOR_ADC_Pin|BATT_TEMP1_ADC_Pin 
                          |LEV_DIST_FL_ADC_Pin|LEV_DIST_FR_ADC_Pin|LEV_DIST_BL_ADC_Pin|LEV_DIST_BR_ADC_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

    /* Peripheral DMA init*/
  
    hdma_adc3.Instance = DMA2_Stream1;
    hdma_adc3.Init.Channel = DMA_CHANNEL_2;
    hdma_adc3.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_adc3.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_adc3.Init.MemInc = DMA_MINC_ENABLE;
    hdma_adc3.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    hdma_adc3.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
    hdma_adc3.Init.Mode = DMA_CIRCULAR;
    hdma_adc3.Init.Priority = DMA_PRIORITY_LOW;
    hdma_adc3.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    HAL_DMA_Init(&hdma_adc3);

    __HAL_LINKDMA(hadc,DMA_Handle,hdma_adc3);

  /* USER CODE BEGIN ADC3_MspInit 1 */

  /* USER CODE END ADC3_MspInit 1 */
  }
}

void HAL_ADC_MspDeInit(ADC_HandleTypeDef* hadc)
{

  if(hadc->Instance==ADC1)
  {
  /* USER CODE BEGIN ADC1_MspDeInit 0 */

  /* USER CODE END ADC1_MspDeInit 0 */
    /* Peripheral clock disable */
    __ADC1_CLK_DISABLE();
  
    /**ADC1 GPIO Configuration    
    PC0     ------> ADC1_IN10
    PC2     ------> ADC1_IN12
    PA0/WKUP     ------> ADC1_IN0
    PA3     ------> ADC1_IN3
    PA4     ------> ADC1_IN4
    PA5     ------> ADC1_IN5
    PA6     ------> ADC1_IN6
    PB0     ------> ADC1_IN8
    PB1     ------> ADC1_IN9 
    */
    HAL_GPIO_DeInit(GPIOC, EC_DIST_Y_ADC_Pin|EC_DIST_X_ADC_Pin);

    HAL_GPIO_DeInit(GPIOA, LEV_DPR_FL_ADC_Pin|LEV_DPR_FR_ADC_Pin|LEV_DPR_BL_ADC_Pin|LEV_DPR_BR_ADC_Pin 
                          |LEV_LOW_PRESS_REG_ADC_Pin);

    HAL_GPIO_DeInit(GPIOB, LEV_HIGH_PRESS_REG_ADC_Pin|LAT_DIST_BACK_ADC_Pin);

    /* Peripheral DMA DeInit*/
    HAL_DMA_DeInit(hadc->DMA_Handle);
  /* USER CODE BEGIN ADC1_MspDeInit 1 */

  /* USER CODE END ADC1_MspDeInit 1 */
  }
  else if(hadc->Instance==ADC2)
  {
  /* USER CODE BEGIN ADC2_MspDeInit 0 */

  /* USER CODE END ADC2_MspDeInit 0 */
    /* Peripheral clock disable */
    __ADC2_CLK_DISABLE();
  
    /**ADC2 GPIO Configuration    
    PC3     ------> ADC2_IN13 
    */
    HAL_GPIO_DeInit(EC_TEMP_1_ADC_GPIO_Port, EC_TEMP_1_ADC_Pin);

    /* Peripheral DMA DeInit*/
    HAL_DMA_DeInit(hadc->DMA_Handle);
  /* USER CODE BEGIN ADC2_MspDeInit 1 */

  /* USER CODE END ADC2_MspDeInit 1 */
  }
  else if(hadc->Instance==ADC3)
  {
  /* USER CODE BEGIN ADC3_MspDeInit 0 */

  /* USER CODE END ADC3_MspDeInit 0 */
    /* Peripheral clock disable */
    __ADC3_CLK_DISABLE();
  
    /**ADC3 GPIO Configuration    
    PF3     ------> ADC3_IN9
    PF4     ------> ADC3_IN14
    PF5     ------> ADC3_IN15
    PF6     ------> ADC3_IN4
    PF7     ------> ADC3_IN5
    PF8     ------> ADC3_IN6
    PF9     ------> ADC3_IN7
    PF10     ------> ADC3_IN8 
    */
    HAL_GPIO_DeInit(GPIOF, LAT_DIST_FRONT_ADC_Pin|BATT_V1_ADC_Pin|EC_ACTUATOR_ADC_Pin|BATT_TEMP1_ADC_Pin 
                          |LEV_DIST_FL_ADC_Pin|LEV_DIST_FR_ADC_Pin|LEV_DIST_BL_ADC_Pin|LEV_DIST_BR_ADC_Pin);

    /* Peripheral DMA DeInit*/
    HAL_DMA_DeInit(hadc->DMA_Handle);
  /* USER CODE BEGIN ADC3_MspDeInit 1 */

  /* USER CODE END ADC3_MspDeInit 1 */
  }
} 

/* USER CODE BEGIN 1 */
/* ADC_config DMAs */
/**
  * @brief  set buffer pointers, main and secondary and configure DMA's to write ADC info there
  * @author AM
  * @param  None
  * @note   Not used
  * @retval None
  */

void ADC_configDMA(void)
{
  HAL_ADC_Start_DMA(&hadc3, (uint32_t*) (adc_3_dmaBuffer), (uint32_t)sizeof(adc_3_dmaBuffer));
	HAL_ADC_Start_DMA(&hadc2, (uint32_t*) (adc_2_dmaBuffer), (uint32_t)sizeof(adc_2_dmaBuffer));
	HAL_ADC_Start_DMA(&hadc1, (uint32_t*) (adc_1_dmaBuffer), (uint32_t)sizeof(adc_1_dmaBuffer));
}

/**
  * @brief  Set buffer pointers, main and secondary and configure DMA's to write ADC info there,
						all 3 ADC's are updated.
  * @author AM
  * @param  hadc
  * @note   Not used
  * @retval None
  */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
	uint16_t i; 
	if (hadc->Instance==ADC1)
	{
		memcpy (&adc_1_workingBuffer, &adc_1_dmaBuffer, sizeof(adc_1_dmaBuffer));
		memset (&adc_1_avgBuffer, 0, sizeof(adc_1_avgBuffer));
		for (i = 0; i < ADC_1_RAW_BUFFER_LENGTH;i++)
		{
			adc_1_avgBuffer[i % ADC_1_MAX_CHANNELS] += adc_1_workingBuffer[i];
		}
		for (i = 0; i < ADC_1_MAX_CHANNELS; i++)
		{
			adc_1_dataBuffer[i] = (uint16_t) adc_1_avgBuffer[i] / ADC_SAMPLES_PER_CHANNEL;	
		}
	}
	else if (hadc->Instance==ADC2)
	{
		memcpy (&adc_2_workingBuffer, &adc_2_dmaBuffer, sizeof(adc_2_dmaBuffer));
		memset (&adc_2_avgBuffer, 0, sizeof(adc_2_avgBuffer));
		for (i = 0; i < ADC_2_RAW_BUFFER_LENGTH;i++)
		{
			adc_2_avgBuffer[i % ADC_2_MAX_CHANNELS] += adc_2_workingBuffer[i];
		}
		for (i = 0; i < ADC_2_MAX_CHANNELS; i++)
		{
			adc_2_dataBuffer[i] = (uint16_t) adc_2_avgBuffer[i] / ADC_SAMPLES_PER_CHANNEL;	
		}
	}
	else if (hadc->Instance==ADC3)
	{
		memcpy (&adc_3_workingBuffer, &adc_3_dmaBuffer, sizeof(adc_3_dmaBuffer));
		memset (&adc_3_avgBuffer, 0, sizeof(adc_3_avgBuffer));
		for (i = 0; i < ADC_3_RAW_BUFFER_LENGTH;i++)
		{
			adc_3_avgBuffer[i % ADC_3_MAX_CHANNELS] += adc_3_workingBuffer[i];
		}
		for (i = 0; i < ADC_3_MAX_CHANNELS; i++)
		{
			adc_3_dataBuffer[i] = (uint16_t) adc_3_avgBuffer[i] / ADC_SAMPLES_PER_CHANNEL;	
		}
	}
}
/**
  * @brief  Returns the ADC value of the DPR's
  * @author AM
  * @param  regulator number (0 based indexing)
  * @note   the value returned is out of 4096
  * @retval uint16_t
  */
uint16_t adc_lev_get_DPR_val(uint8_t regulatorNumber)
{
	return (adc_1_dataBuffer[regulatorNumber]); //0..3
}
/**
  * @brief  Returns the ADC value of the lev low pressure regulator
  * @author AM
  * @param  none
  * @note   the value returned is out of 4096
  * @retval uint16_t
  */
uint16_t adc_lev_get_low_press_val(void)
{
	return (adc_1_dataBuffer[LEV_LOW_PRESS_REG_IDX]); //4
}
/**
  * @brief  Returns the ADC value of the high pressure regulator
  * @author AM
  * @param  none
  * @note   the value returned is out of 4096
  * @retval uint16_t
  */
uint16_t adc_lev_get_high_press_val(void)
{
	return (adc_1_dataBuffer[LEV_HIGH_PRESS_REG_IDX]); //5
}
/**
  * @brief  Returns the ADC value of the EC distnace sensors
  * @author AM
  * @param  distance sensor number(0 based indexing)
  * @note   the value returned is out of 4096, 	PB1 is dist sensor 0, then PC0, PC2 (try these if PB1 doesn't work)
  * @retval uint16_t
  */
/**
  * @brief  Returns the ADC value of the voltage levels of the battery
  * @author AM
  * @param  distnace sensor number(0 based indexing)
  * @note   the value returned is out of 4096
  * @retval uint16_t
  */
uint16_t adc_lat_get_back_dist_val(void)
{
	return (adc_1_dataBuffer[LAT_DIST_BACK_IDX]); //6
}
/**
  * @brief  Returns the ADC value of the EC distnace sensors
  * @author AM
  * @param  distance sensor number(0 based indexing)
  * @note   the value returned is out of 4096
  * @retval uint16_t
  */
uint16_t adc_EC_get_distY_val(void)
{
	return (adc_1_dataBuffer[EC_DIST_Y_IDX]); //7
}
/**
  * @brief  Returns the ADC value of the EC distnace sensors
  * @author AM
  * @param  distance sensor number(0 based indexing)
  * @note   the value returned is out of 4096
  * @retval uint16_t
  */
uint16_t adc_EC_get_distX_val(void)
{
	return (adc_1_dataBuffer[EC_DIST_X_IDX]); //8
}
/**
  * @brief  Returns the ADC value of the EC temperature sensor
  * @author AM
  * @param  none
  * @note   the value returned is out of 4096
  * @retval uint16_t
  */
uint16_t adc_EC_get_temp_val(void)
{
	return (adc_2_dataBuffer[EC_TEMP_IDX]); //0
}
/**
  * @brief  Returns the ADC value of the battery temperature regulator
  * @author AM
  * @param  none
  * @note   the value returned is out of 4096
  * @retval uint16_t
  */
uint16_t adc_batt_get_temp_val(void)
{
	return (adc_3_dataBuffer[BATT_TEMP_IDX]); //0
}
/**
  * @brief  Returns the ADC value of the lev distance sensors 
  * @author AM
  * @param  distnace sensor number(0 based indexing)
  * @note   the value returned is out of 4096
  * @retval uint16_t
  */
uint16_t adc_lev_get_dist_val(uint8_t distNumber)
{
	return (adc_3_dataBuffer[distNumber + LEV_DIST_IDX_OFFSET]); //1..4 + 1
}
/**
  * @brief  Returns the ADC value of the voltage levels of the battery
  * @author AM
  * @param  distnace sensor number(0 based indexing)
  * @note   the value returned is out of 4096
  * @retval uint16_t
  */
uint16_t adc_lat_get_front_dist_val(void)
{
	return (adc_3_dataBuffer[LAT_FRONT_DIST_IDX]); //5
}
/**
  * @brief  Returns the ADC value of the voltage levels of the battery
  * @author AM
  * @param  distnace sensor number(0 based indexing)
  * @note   the value returned is out of 4096
  * @retval uint16_t
  */
uint16_t adc_batt_get_V1_val(void)
{
	return (adc_3_dataBuffer[BATT_V1_IDX]); //6
}
/**
  * @brief  Returns the ADC value of the EC brake actuator
  * @author AM
  * @param  none
  * @note   the value returned is out of 4096
  * @retval uint16_t
  */
uint16_t adc_EC_get_actuator_val(void)
{
	return (adc_3_dataBuffer[EC_ACTUATOR_IDX]); //7
}
/* USER CODE END 1 */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
