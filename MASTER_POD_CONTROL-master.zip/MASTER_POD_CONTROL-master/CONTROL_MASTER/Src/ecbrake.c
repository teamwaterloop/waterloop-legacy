////////////////////////////////////////////////////////////////////////////////
//These test descriptions need to be updated. Read the description of each test function in ecbrake.h instead
//BEFORE TESTING: values of MIN_SEPARATION_FROM_RAIL and PHOT0_DIST_OFFSET need to be set after brakes are mounted
//MIN_SEPARATION_FROM_RAIL is the distance from the face of the magnets to the rail when the actuator is at min extension
//PHOT0_DIST_OFFSET is the difference in distances to the beam from the photoelectric sensors and the face of the magnets

/* EC Brake tests
* TEST 1: Actuator movement - Actuator moves in and out through set points
* to do test: Change const TEST_NUM to 0, and call "EC_brake_main(0); in main while loop of main.c
*
*
* TEST 2: EC - Friction transition test
* Waits a set time until ec starts, then waits another set time until friction starts. Next EC shuts off and friction releases after ten seconds
* to do test: change TEST_NUM to 1, call "EC_testScript(); in main.c main while loop
* constants:
* EC_TOTAL_ACTUATION_TIME - time that EC is on
* EC_START_TIME_DELAY - time until ec starts
* FRICTION_START_DELAY_AFTER_EC - time until friction starts, counting from start of EC
* 
*
* TEST 3: constant actuator test: waits a set number of seconds, then moves actuator from max extension to a set distance
* to do test: change TEST_NUM to 2, call "EC_Brake_main(0);" in main.c main while loop
* constants:
*
* EC_CONST_DIST_TEST_DELAY time delay until actuation to specified distance
* EC_CONST_DIST_TEST_DIST distance that actuator will move to after delay
*//////////////////////////////////////////////////////////////////////////////


#define TEST_NUM 2
#define ACTUAL_RUN


#include "ecbrake.h"
#include "tim.h"
#include "adc.h"
#include "gpio.h"

///////////////////////////// Constants /////////////////////////////////
/* Make sure float constants have suffix of f - e.g. "#define PI 3.14f */

//Actuator constants
#define MAX_ACTUATOR_DISTANCE 50 //length of full extension divided by 2
#define MIN_ACTUATOR_DISTANCE 0  //zero extension
#define MAX_PWM_DUTY 100
#define MIN_PWM_DUTY 0
#define MIN_SEPARATION_FROM_RAIL 7.15f //millimeters //distance of magnets from rail when actuator has zero extension
//ACTUATOR_READ_IN - these may need to be further calibrated before the range test works
#define ACTUATOR_ADC_MIN 800 //value the adc reads when actuator is at min extention
#define ACTUATOR_ADC_MAX 4096 //value the adc reads when actuator is at max extention

//TEMP CONSTANTS
#define OVERHEAT_TEMP 50
#define NUM_TEMP_ADC_SENSORS 2
#define NUM_TEMP_DIG_SENSORS 1
#define TEMP_MIN_ADC 0
#define TEMP_REF_TEMP_ADC 0.01*100/3.3*4096.0f //adc return value at a reference temperature
#define TEMP_MIN 0
#define TEMP_REFERENCE 100


//DISTANCE SENSOR CONSTANTS
#define NUM_DISTANCE_SENSORS 3
#define PHOTO_DIST_ADC_MIN 4096/10.0f
#define PHOTO_DIST_ADC_MAX 4096
#define PHOTO_MIN_DIST_MM 20
#define PHOTO_MAX_DIST_MM 80
#define PHOT0_DIST_OFFSET 20 //distance photoelectric sensor reads when distance of magnets from beam is zero
														 //needs to be measured once sensor is mounted. Distance is in mm

//TESTING CONSTANTS
#define EC_TOLERANCE 3  //milimetres
#define EC_TIMEOUT 2000 //miliseconds.

//ec - friction transition test
#define TEST_0_DELAY_TIME 1000
#define EC_TOTAL_ACTUATION_TIME 45000
#define EC_START_TIME_DELAY 5000
#define FRICTION_START_DELAY_AFTER_EC 20000


#define EC_CONST_DIST_TEST_DELAY 5000
#define EC_CONST_DIST_TEST_DIST 30 //mm
typedef enum { false, true } bool;	


///////////////////////////////
// Helper function prototypes//
///////////////////////////////
static float linearMap(float value, float from_lower, float from_upper, float to_lower, float to_upper);
static int EC_read_temp(void);
static float EC_read_photo_senor_distance(uint16_t sensor_num);
static float EC_read_actuator_distance(void);
static float ecBrake_next_distance(float actuator_dist, float photoelectric_dist);
static void ec_brake_set_actuator_position(float distance_from_rail);
///////////////////////////////



// Maps a value from one range of values to another
/*
static float linearMap(float value, float from_lower, float from_upper, float to_lower, float to_upper){
  return ((to_upper - to_lower)*(value - from_lower)/(from_upper - from_lower)) + to_lower;
}


static int EC_read_temp(void){
	//0-4096
	uint32_t adc_temp_Val = adc_EC_get_temp_val();
	return linearMap(adc_temp_Val,TEMP_MIN_ADC,TEMP_REF_TEMP_ADC,TEMP_MIN,TEMP_REFERENCE);
	//calculate temperature
	//need to find range of values from adc
}

//read a distance from the specified photoelectric distance sensor
static float EC_read_photo_senor_distance(uint16_t sensor_num){
	//0-4096
	uint32_t adc_dist_val = adc_EC_get_actuator_val();
	//uint32_t adc_dist_val = adc_EC_get_dist_val(sensor_num);
	return linearMap(adc_dist_val,PHOTO_DIST_ADC_MIN,PHOTO_DIST_ADC_MAX,PHOTO_MIN_DIST_MM,PHOTO_MAX_DIST_MM) - PHOT0_DIST_OFFSET;
}

//read the current separation of magnets from the rail, as measured by the actuator feedback.
static float EC_read_actuator_distance(void)
{
	return linearMap(adc_EC_get_actuator_val(),ACTUATOR_ADC_MIN,ACTUATOR_ADC_MAX,MIN_SEPARATION_FROM_RAIL,MAX_ACTUATOR_DISTANCE+MIN_SEPARATION_FROM_RAIL);
}

//calculates new separation distance from rail based on speed and prevoius distance, as per modelling team's calculations
static float ecBrake_next_distance(float actuator_dist, float photoelectric_dist)//, float velocity = 150)//params tbd
{ //need proper calculation
	//calculation
	float calculated_distance = actuator_dist;//placeholder
	
	//make sure return value is not smaller than the minimum separation distance.
	return (calculated_distance < MIN_SEPARATION_FROM_RAIL) ? MIN_SEPARATION_FROM_RAIL:calculated_distance;
	
}

static void ec_brake_set_actuator_position(float distance_from_rail)
{
	//transfer distance to pwm threshold
	float actuator_distance = distance_from_rail - MIN_SEPARATION_FROM_RAIL;
	//make sure the actuator is not getting set to a negative value or a value greater than 100mm
	actuator_distance = (actuator_distance < MIN_ACTUATOR_DISTANCE) ? MIN_ACTUATOR_DISTANCE:actuator_distance;
	actuator_distance = (actuator_distance > MAX_ACTUATOR_DISTANCE) ? MAX_ACTUATOR_DISTANCE:actuator_distance;
	//set the actuator to the corresponding duty cycle
	TIM_EC_pressure_set_PWM (linearMap(actuator_distance,MIN_ACTUATOR_DISTANCE,MAX_ACTUATOR_DISTANCE,MIN_PWM_DUTY,MAX_PWM_DUTY));
}

void EC_Brake_init()//TIM_HandleTypeDef* actuator_tim_handle, GPIO_TypeDef* temp_dig_gpiox,uint16_t dig_temp_pin)
{
	TIM_EC_pressure_set_PWM (100); //pushes to farthest distance
}







EC_failure_type EC_Brake_main(int velocity)//, int acceleration,int* temp_adc_values, int* distance_adc_values)
{ //called during each loop of the state machine

	//variables needed
	int i = 0;
	bool overheat = false;
	uint32_t temp;
	float actuator_dist;
	float photoelectric_distance[NUM_DISTANCE_SENSORS];
	float distance_from_rail;

	
	//Read all sensor data
	
	//temperature
	
	temp = EC_read_temp();
		
	if (temp > OVERHEAT_TEMP)
		overheat = true;
		
	
		//if(HAL_GPIO_ReadPin(EC_Brake.temp_gpiox,EC_Brake.temp_gpio_pin))
		//	overheat = true;
	if (overheat)
		;//set flag
	
	
	//distance
	actuator_dist = EC_read_actuator_distance();
	for (i = 0; i < NUM_DISTANCE_SENSORS; i++)
	{
		photoelectric_distance[i] = EC_read_photo_senor_distance(i);//adc_EC_get_dist_val(i));
	}
	
	//TODO: may need hall effect sensor eventually. would get these values passed in from ADC
	#ifdef ACTUAL_RUN
	//perform feedback operations
	//need details from math team
	distance_from_rail = ecBrake_next_distance(actuator_dist, photoelectric_distance[0]);
	
	
	//call output (pwm)
	ec_brake_set_actuator_position(distance_from_rail);
	#endif
	
	
	#ifdef TESTING
	//TODO figure out logging info
	//TODO make sure actuator works
	uint32_t current_time = HAL_GetTick();
	switch (TEST_NUM)
	{
		case 0:
		break;
		
		case 1:
				
		break;
		
		case 2:

		break;

		case 3:

		break;
		
	}//end switch
	#endif
	
	return EC_OK;
	//return flags?
}
*/
/*
int some = 0;
unsigned long time;
time = testScript(time, &some)
*/
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Test Script for ec/friction transition//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//helper for the testscript
EC_failure_type EC_fric_transition_actuate_ec(uint32_t time_since_ec_started)
{
			if (time_since_ec_started < EC_TOTAL_ACTUATION_TIME*0.1) {
				ec_brake_set_actuator_position(10);
			}
			else if (time_since_ec_started < EC_TOTAL_ACTUATION_TIME*0.2) {
				ec_brake_set_actuator_position(0);
			}
			else if (time_since_ec_started < EC_TOTAL_ACTUATION_TIME*0.3) {
				ec_brake_set_actuator_position(0);
			}
			else if (time_since_ec_started < EC_TOTAL_ACTUATION_TIME*0.4) {
				ec_brake_set_actuator_position(5);
			}
			else if (time_since_ec_started < EC_TOTAL_ACTUATION_TIME*0.5) {
				ec_brake_set_actuator_position(10);
			}
			else if (time_since_ec_started < EC_TOTAL_ACTUATION_TIME*0.6) {
				ec_brake_set_actuator_position(20);
			}
			else if (time_since_ec_started < EC_TOTAL_ACTUATION_TIME*0.7) {
				ec_brake_set_actuator_position(30);
			}
			else if (time_since_ec_started < EC_TOTAL_ACTUATION_TIME*0.8) {
				ec_brake_set_actuator_position(40);
			}
			else if (time_since_ec_started < EC_TOTAL_ACTUATION_TIME*0.9) {
				ec_brake_set_actuator_position(45);
			}
			else if (time_since_ec_started < EC_TOTAL_ACTUATION_TIME*1.0) {
				ec_brake_set_actuator_position(50);
			}
			return EC_OK;
}


int current_sequence;
uint32_t last_sig_time = 0;
uint32_t ec_start_time = 0;
EC_failure_type EC_fric_transition_test(){

	//current_sequence: 0 = wait 5s, 1 = do EC brake, wait 20s, 2 = do Friction brake, 3 = wait 25s while still actuating, 4 = stop EC brake, 5 = wait till velo is zero then stop Friction brake

	unsigned long time_now = HAL_GetTick();
	int delay_sequence[4] = {EC_START_TIME_DELAY, FRICTION_START_DELAY_AFTER_EC, EC_TOTAL_ACTUATION_TIME - FRICTION_START_DELAY_AFTER_EC,10000};

	switch(current_sequence) {
		case 0:
			if (time_now - last_sig_time < delay_sequence[0])
				;
			else {
				current_sequence++;
				ec_start_time = time_now;
				last_sig_time = time_now;
			}
			break;
		case 1:
			if (time_now - last_sig_time < delay_sequence[1])
				EC_fric_transition_actuate_ec(time_now-ec_start_time);
			
			else {
				current_sequence++;
				last_sig_time = time_now;
			}
			break;
		case 2:
			//FRICTION FUNCTION HERE
			GPIO_frict_actuate_enable();
		
			current_sequence++;
			last_sig_time = time_now;
			break;
		case 3:
			if (time_now - last_sig_time < delay_sequence[2])
			{
				EC_fric_transition_actuate_ec(time_now - ec_start_time);
			}
			else {
				current_sequence++;
				last_sig_time = time_now;
			}
			break;
		case 4:
			//STOP EC BRAKE HERE
			
			TIM_EC_pressure_set_PWM(MAX_PWM_DUTY);
			current_sequence++;
			last_sig_time = time_now;
		break;
		case 5:
			if (time_now - last_sig_time < delay_sequence[3])
				;
			else {
				current_sequence++;
				last_sig_time = time_now;
			}
			break;
		case 6:
			current_sequence = 99;
			//STOP FRICTION BRAKE HERE
			GPIO_frict_actuate_disable();
			break;
	}
	return EC_OK;
}


int distances[9] = {50,10,0,5,20,25,30,40,50};
int range_test_stage = 0;
uint32_t range_test_lastTick= 0;
float range_test_desired_distance = 0;
int range_test_target_achieved = 0;
EC_failure_type EC_range_test(void)
{	//time sequenced actuation
		float actuator_distance_in;
		float photo_distance[NUM_DISTANCE_SENSORS];
		uint32_t current_time = HAL_GetTick();
	int i = 0;
	actuator_distance_in = EC_read_actuator_distance();
		for (i = 0; i < NUM_DISTANCE_SENSORS; i++)
	{
		photo_distance[i] = EC_read_actuator_distance();//adc_EC_get_dist_val(i));
	}
			
		
		//return a failure if the actuator can not reach its target location
		if (actuator_distance_in < range_test_desired_distance- EC_TOLERANCE || actuator_distance_in > range_test_desired_distance + EC_TOLERANCE)
		{//not in target range: check timeout
			if (current_time - range_test_lastTick > EC_TIMEOUT)		
				return EC_GENERAL_FAILURE;
			else
				return EC_IN_PROGRESS;
		}
		else
		{ // target is achieved. May want to reset last tick here in order to pause at the desired location rather than possibly start moving right away
			//first check to see if the photoelectric sensors agree with the actuator read in
			if (photo_distance[0] < range_test_desired_distance- EC_TOLERANCE || photo_distance[0] > range_test_desired_distance + EC_TOLERANCE)
			{//disagree
				return EC_ACTUATOR_PHOTO_DISAGREE;
			}
			else
			
				range_test_target_achieved = 1;
		}
		
		if (current_time - range_test_lastTick > TEST_0_DELAY_TIME && range_test_target_achieved)
		{//time delay is done and target is achieved
			range_test_lastTick = current_time;
			range_test_stage++;
			range_test_stage = (range_test_stage > 10)?0:range_test_stage;
			range_test_desired_distance = distances[range_test_stage];
			ec_brake_set_actuator_position(range_test_desired_distance);
			range_test_target_achieved = 0;
		}
		return EC_OK;
}

uint32_t const_dist_test_start_time = 0;
bool const_dist_test_started = false;
EC_failure_type EC_const_dist_test(float distance, uint32_t delay_time)
{
			uint32_t current_time = HAL_GetTick();	
			if(!const_dist_test_started)
			{
				const_dist_test_started = true;
				const_dist_test_start_time = current_time;
				return EC_NOT_YET_ACTUATED;
			}
			else{
				if(current_time - const_dist_test_start_time > delay_time){
					ec_brake_set_actuator_position(distance);
				}
				else
				{
					ec_brake_set_actuator_position(MAX_PWM_DUTY);
				}
			}
			return EC_OK;
}


void EC_photo_distance_sensor_test(int photo_sensor_num, int test_distance)
{
	/////NEED TO FIND OUT WHAT PIN THIS CORRESPONDS TO////
	float distance = EC_read_photo_senor_distance(0);
	
	if (distance > test_distance)
		HAL_GPIO_WritePin(GPIOB,LD3_Pin,GPIO_PIN_SET);
	else
		HAL_GPIO_WritePin(GPIOB,LD3_Pin,GPIO_PIN_RESET);
	
}

void EC_actuator_distance_sensor_test(int test_distance)
{
	float distance = EC_read_actuator_distance();
	
	if (distance > test_distance)
		HAL_GPIO_WritePin(GPIOB,LD3_Pin,GPIO_PIN_SET);
	else
		HAL_GPIO_WritePin(GPIOB,LD3_Pin,GPIO_PIN_RESET);
	
}

uint32_t delayed_friction_test_start_time = 0;
bool delayed_friction_test_started = false;
void FRICTION_actuate_after_delay(uint32_t delay_time)
{
		uint32_t current_time = HAL_GetTick();	
		if(!delayed_friction_test_started)
		{
			delayed_friction_test_started = true;
			delayed_friction_test_start_time = current_time;
			return;// EC_NOT_YET_ACTUATED;
		}
		else{
			if(current_time - delayed_friction_test_start_time > delay_time){
				GPIO_frict_actuate_enable();
			}
			else
			{
				GPIO_frict_actuate_disable();
			}
		}
}


// this is the array that needs to get filled by our script. unfortunately it must be in this file
//
float array_sequenced_actuation_distance[10000] = {0};
uint32_t array_sequenced_test_start_time = 0;
uint32_t array_sequenced_actuation_start_time = 0;
bool array_sequenced_test_started = false;
bool array_sequenced_actuation_started = false;
void EC_array_based_actuation_test(uint32_t delay_until_start)
{
			uint32_t current_time = HAL_GetTick();	
			if(!array_sequenced_test_started)
			{//first time called, set the start time to know when to start actuating
				array_sequenced_test_started = true;
				array_sequenced_test_start_time = current_time;
				
			}
			else if (!array_sequenced_actuation_started)
			{//actuation starting - set time of actuation start so that the appropriate array index can be called later
				if(current_time - array_sequenced_test_start_time > delay_until_start){
					array_sequenced_actuation_started = true;
					array_sequenced_actuation_start_time = current_time;
				}
			}
			else
			{ //actuate to the appropriate distance
				if (current_time - array_sequenced_actuation_start_time < 20000)
				{
					ec_brake_set_actuator_position(array_sequenced_actuation_distance[(uint32_t)(current_time-array_sequenced_actuation_start_time)]); //array uses time since actuation started in ms
																																																																						//must give desired distance in mm
				}	
				else
					ec_brake_set_actuator_position(MAX_ACTUATOR_DISTANCE); //release the break after a long period of time (20s)
			}
			
		
	
	
	
}

*/
/*
uint16_t adc_EC_get_dist_val(uint8_t distNumber);
uint16_t adc_EC_get_temp_val(void);
uint16_t adc_EC_get_actuator_val(void);
void TIM_EC_pressure_set_PWM (uint16_t dutyCycle);


*/

