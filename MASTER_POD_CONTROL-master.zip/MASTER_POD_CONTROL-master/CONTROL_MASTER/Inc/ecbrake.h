#ifndef ECBRAKE_H
#define ECBRAKE_H

//#define EC_FAILURE 0xFFFF
//#define EC_IN_PROGRESS 0x5555

#include "stm32f7xx.h"
#include "stm32f7xx_hal.h"
#include "stm32f7xx_hal_adc.h"
#include "stm32f7xx_hal_gpio.h"
#include "stm32f7xx_hal_tim.h"


typedef struct EC_brake_instance{
	GPIO_TypeDef* temp_gpiox;
	uint16_t temp_gpio_pin;
	TIM_HandleTypeDef* ec_brake_actuator;
	
	//info on current/recent conditions	
}Ec_brake_instance_t;

typedef enum
{
	EC_ACTUATOR_NOT_MOVING,
	EC_ACTUATOR_PHOTO_DISAGREE,
	EC_NOT_YET_ACTUATED,
	//add more errors or other return info
	
	EC_GENERAL_FAILURE,
	EC_OK,
	EC_IN_PROGRESS
}EC_failure_type;


//call this function in the setup code so ecbrake has access to the HAL structs it requires
/*
* param: actuator_tim_handle - pointer to the pwm handler for the actuator
* dig_temp_gpiox - pointer to the GPIO_TypeDef for the GPIO line that temperature digital pin is on (e.g. gpioa, gpiob, etc)
* dig_temp_pin - digital temperature pin number
*
*/
void EC_Brake_init(void);//TIM_HandleTypeDef* actuator_tim_handle, GPIO_TypeDef* dig_temp_gpiox,uint16_t dig_temp_pin);


//call when ec brake action is needed
/*
* param: veleocity - current velocity
* param: acceleration - current acceleration
* tempAdcValues - array of all analog temp pin readings (may end up being just 1)
* distance_adc_values - array of the 3 distance sensor readings
*
* return value: returns EC_failure_type describing the faliure
*/
EC_failure_type EC_Brake_main(int velocity);//, int acceleration,int* tempAdcValues, int* distance_adc_values);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Test case functions for EC braking.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//BEFORE TESTING: values of MIN_SEPARATION_FROM_RAIL and PHOT0_DIST_OFFSET need to be set after brakes are mounted (constants are in ecbrake.c
//MIN_SEPARATION_FROM_RAIL is the distance from the face of the magnets to the rail when the actuator is at min extension
//PHOT0_DIST_OFFSET is the difference in distances to the beam from the photoelectric sensors and the face of the magnets


//loops through a range of distances while making sure that the actuator and photoelectric sensors agree
//returns appropriate errors
//call this repeatedly from the main loop 
EC_failure_type EC_range_test(void);


//after a set amount of time, actuate the ec brake to a specified distance from the beam
//call this repeatedly from the main loop 
EC_failure_type EC_const_dist_test(float distance, uint32_t delay_time);


//Uses times set in constants to wait a set time until ec starts, then wait another set time until friction starts. Next EC shuts off and friction releases after ten seconds
//call this repeatedly from the main loop 
EC_failure_type EC_fric_transition_test(void);

//for debugging the photoelectric sensor
//turn a light on if the photoelectric sensor senses a distance greater than the one specified 
//note that it operates based on the distance of the magnets from the beam, not the distance of the object from the sensor
//needs to know which photo sensor is being read from, as there are currently 3 allocated to EC in the code setup and I don't know which goes with which pin
void EC_photo_distance_sensor_test(int photo_sensor_num, int test_distance);

//for debugging the actuator feedback value
//turn a light on if the actuator feedback sensor senses a distance greater than the one specified 
//note that it operates based on the distance of the magnets from the beam, not the distance of the actual extension of the sensor
void EC_actuator_distance_sensor_test(int test_distance);


//after the delay time, the actuator moves through a series of positions stored in an array copied from the output of jake's script
//call this repeatedly from the main loop 
void EC_array_based_actuation_test(uint32_t delay_until_start);
//void FRICTION_actuate_after_delay(uint32_t delay_time);

#endif
