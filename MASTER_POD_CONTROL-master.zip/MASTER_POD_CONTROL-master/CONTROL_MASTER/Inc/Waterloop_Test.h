#ifndef WATERLOOP_TEST_H
#define WATERLOOP_TEST_H

#include <stdlib.h>
#include <stdint.h>

#define LEV_TEST 0
#define EC_TEST 1
#define FRICTION_TEST 2
#define DRIVE_TEST 3

void lev_test_one (void);
void EC_brake_test (void);
void friction_brake_test(void);
void execute_test(uint8_t test);

#endif
