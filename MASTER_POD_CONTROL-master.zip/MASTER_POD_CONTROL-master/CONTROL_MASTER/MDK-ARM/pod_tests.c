#include <stdint.h>
#include "gpio.h"
#include "tim.h"
#include "adc.h"
#include "usart.h"
#include "pod_tests.h"

#define SET 1
#define RESET 0

/*
lev_test_one is reading the downstream pressure 
from all of the DPRs - (Expected Value is 0-100 psi)
from high pressure transmitter - (0-3000 psi)
from low pressure transmitter - (0-100 psi)
*/

void lev_test_one (){
	
	uint16_t current_time = 0;	
	uint16_t last_time = 0;
	
	GPIO_LEV_enable();
	TIM_lev_set_DPR_BR_PWM (75);
	TIM_lev_set_DPR_FR_PWM (75);
	TIM_lev_set_DPR_FL_PWM (75);
	TIM_lev_set_DPR_BL_PWM (75);
	current_time = HAL_GetTick();
	last_time = current_time;
	while (current_time - last_time < 30000) 
	{
	
		current_time = HAL_GetTick();
		
		SendTransmissionContract();		
	}
	
	GPIO_LEV_disable();
	TIM_lev_set_DPR_BR_PWM (0);
	TIM_lev_set_DPR_FR_PWM (0);
	TIM_lev_set_DPR_FL_PWM (0);
	TIM_lev_set_DPR_BL_PWM (0);
}

void EC_brake_test () {
	
	uint16_t current_time = 0;
	uint16_t last_time = 0;
	
	uint16_t actuator_val = 0;
	uint16_t EC_dist_val = 0;
	uint16_t EC_temp_val = 0;
	uint16_t EC_expt_dist_val = 0;
	double threshold = 0.1; 
	
	GPIO_LEV_enable();
	TIM_lev_set_DPR_BR_PWM (75);
	TIM_lev_set_DPR_FR_PWM (75);
	TIM_lev_set_DPR_FL_PWM (75);
	TIM_lev_set_DPR_BL_PWM (75);
	
	while (current_time - last_time < 30000 || last_time == 0) {
	
		current_time = HAL_GetTick();
	
		actuator_val = adc_EC_get_actuator_val();		
		EC_dist_val = adc_EC_get_distX_val();
		EC_temp_val = adc_EC_get_temp_val();

		SendTransmissionContract();
				
		// Essentially: check individual subsystem�s 
		//sensors, if they are not working, then activate
		// EC brake, if actuator is not working, activate
		// friction brakes. 
		// assuming these return a value when no 
		// electricity is going to them. 

		if (EC_dist_val == 0 || abs((EC_expt_dist_val - EC_dist_val)/EC_expt_dist_val) < threshold) {
		//activate EC brake
		}
		
		else if (EC_temp_val == 0) {
		//activate EC brake
		}
		
		else {
			last_time = HAL_GetTick();
		}

		// checking the actuator lets us see if the 
		// actuator is still working. 
		// if the actuator is not working, then there 
		// should not be an output from it

		if (actuator_val == 0) {
			GPIO_frict_actuate_enable();
		}
		
		else {
			last_time = HAL_GetTick();
		}
	}
	GPIO_LEV_disable();
	TIM_lev_set_DPR_BR_PWM (0);
	TIM_lev_set_DPR_FR_PWM (0);
	TIM_lev_set_DPR_FL_PWM (0);
	TIM_lev_set_DPR_BL_PWM (0);
}

//Actuation of friction brakes test
void friction_brake_test() {
	
	GPIO_LEV_enable();
	TIM_lev_set_DPR_BR_PWM (75);
	TIM_lev_set_DPR_FR_PWM (75);
	TIM_lev_set_DPR_FL_PWM (75);
	TIM_lev_set_DPR_BL_PWM (75);
	HAL_Delay(2000);
	//wanted lateral too
	GPIO_drive_actuate_disable();
	HAL_Delay(5000);
	if (drive_get_reed_value()) {
		GPIO_frict_actuate_enable();
		HAL_Delay(10000);
	}
	
	else {}
	
	if (!drive_get_reed_value()) {
		//activate ec or flag some sort of error - not specified
	}
	GPIO_frict_actuate_disable();
	GPIO_LEV_disable();
	TIM_lev_set_DPR_BR_PWM (0);
	TIM_lev_set_DPR_FR_PWM (0);
	TIM_lev_set_DPR_FL_PWM (0);
	TIM_lev_set_DPR_BL_PWM (0);
}

void drive_test() {
	GPIO_LEV_disable();
	if (drive_get_reed_value()) {
		GPIO_drive_actuate_enable();
		HAL_Delay(5000);
	}
	else {}
	
	if (!drive_get_reed_value()) {
		//activate motor
		HAL_Delay (10000);
	}
	
	else {}
	
	//deactivate motor
	GPIO_drive_actuate_disable();
	
	if (drive_get_reed_value()) {
	 //flag whatever success thing you want
	}
	else {}
		
	GPIO_drive_actuate_disable();
}


void execute_test(uint8_t test) {
	switch(test) {
		case LEV_TEST:
			lev_test_one();
			break;
		case EC_TEST:
			EC_brake_test();
			break;
		case FRICTION_TEST:
			friction_brake_test();
			break;
		case DRIVE_TEST:
			drive_test();
			break;
		default:
			break;
	}
}