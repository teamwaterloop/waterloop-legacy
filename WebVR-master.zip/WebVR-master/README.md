# Three Starter
Three.js boiplerplate with es6 and Webpack 2 with tree shaking.
