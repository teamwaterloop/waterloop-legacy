'use strict';

require('dotenv').config();
let express = require('express');
let app = express();

app.use('/repo-update', require('uphook').gitlab({
  secret: process.env.SECRET,
  callback: function(){
    require('child_process').exec('npm run build', function(){
      process.exit(0); // PM2 will restart it
    });
  }
}));

app.use(express.static('public'));

let listener = app.listen(process.env.PORT || 3000, function () {
  console.log('Waterloop VR on :' + listener.address().port + '!');
});
