import * as THREE from 'three';

import OBJLoader from 'three-obj-loader';

OBJLoader(THREE);

const {Scene, PerspectiveCamera, WebGLRenderer, BoxGeometry, MeshLambertMaterial} = THREE;


export default class Engine{

    init(loading){

        const self = this;

        self.loadingManager.onProgress = loading;

        self.renderer.setSize(window.innerWidth, window.innerHeight);
        self.renderer.domElement.style.opacity = 0;
        document.body.appendChild(self.renderer.domElement);


        var path = "resources/environment/"; 
        var format = '.jpg';
        var urls = [
            path + 'posx' + format, path + 'negx' + format,
            path + 'posy' + format, path + 'negy' + format, 
            path + 'posz' + format, path + 'negz' + format
        ];

        var reflectionCube = new THREE.CubeTextureLoader(self.loadingManager).load( urls );
        reflectionCube.format = THREE.RGBFormat;
        console.log(reflectionCube);
        self.scene.background = reflectionCube;

        const material = new MeshLambertMaterial({ color: 0x212121, reflectivity: 0.7, envMap: self.scene.background });

        var mesh = null;
        var loader = new THREE.OBJLoader();
        loader.load("hyperloop.obj",function ( obj ) {
            obj.traverse(function (child) {
                if (child instanceof THREE.Mesh) {
                    child.material = material;
                }
            });
            obj.rotation.y = 180;
            mesh = obj;
            self.scene.add( obj );
            animate();
        });


        var ambientLight = new THREE.AmbientLight( 0x000000 );
        self.scene.add( ambientLight );

        var directionalLight = new THREE.DirectionalLight( 0xFFFFFF );
        directionalLight.position.x = 0;
        directionalLight.position.y = 0;
        directionalLight.position.z = 500;
        directionalLight.position.normalize();
        self.scene.add( directionalLight );

        var light = new THREE.PointLight( 0x212121, 100, 1000 );
        light.position.set( 500, 500, -500 );
        self.scene.add( light );

        self.camera.position.z = -400;

        var mouseX = 0;
        var mouseY = 0;

        var windowHalfX = window.innerWidth/2;
        var windowHalfY = window.innerHeight/2;


        function onDocumentMouseMove(event) {
            mouseX = ( event.clientX - windowHalfX ) * 4;
            mouseY = ( event.clientY - windowHalfY ) * 4;
        }

        function render() {
            self.camera.position.x += ( mouseX - self.camera.position.x ) * .05;
            self.camera.position.y += ( - mouseY - self.camera.position.y ) * .05;
            self.camera.lookAt( self.scene.position );
            self.renderer.render(self.scene, self.camera);
        }

        function animate() {
            requestAnimationFrame( animate ); 
            if(mesh != null){
                render();
            }
        }
        document.addEventListener('mousemove', onDocumentMouseMove, false);

    }

    constructor(){

        this.scene = new Scene();
        this.camera = new PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 10000);
        this.renderer = new WebGLRenderer();
        this.loadingManager = new THREE.LoadingManager();

    }
}