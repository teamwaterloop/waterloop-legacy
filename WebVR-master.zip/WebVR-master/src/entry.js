import Vivus from 'vivus';
import Engine from './engine';

new Vivus('loader', {start: 'manual', animTimingFunction: Vivus.LINEAR, duration: 200, type: 'sync', onReady: function(loader){
  document.getElementById('loader').style.visibility = "visible";
  const engine = new Engine();
  var progress = 0.05, realProgress = 0; //track visible progress and real loading progress
  function animate(){
    if(progress < realProgress){
      progress += 0.05;
      loader.setFrameProgress(progress);
    }
    if(progress >= 1){
      setTimeout(function(){
        document.getElementById('loader').style.display = 'none';
        engine.renderer.domElement.style.opacity = 1;
      }, 300);
    }else{
      setTimeout(animate, 10);
    }
  }
  animate();
  engine.init(function(item, loaded, total){
    realProgress = loaded/total;
  });
}}); 