/*
Code to output to file and/or database
*/

package main

import (
	"encoding/json"
	"fmt"
	"os"
	"strconv"
	"time"
)

// Should be run as goroutine
func outputThread(data *[]podUpdate) {
	OUTPUT_FILE := "output/data.json" // relative to binary's location

	out_file, err := os.OpenFile(OUTPUT_FILE, os.O_APPEND|os.O_RDWR, 0666)
	defer out_file.Close()
	if err != nil {
		fmt.Println("Failed to open file " + OUTPUT_FILE)
		panic("Failed to open data file")
	}

	dataPosition := 0
	currLength := len(*data)
	// We assume ~30 Hz from the STM
	for {
		time.Sleep(time.Second * 5)
		if currLength == len(*data) {
			continue
		}

		currLength = len(*data)
		to_output := (*data)[dataPosition:currLength]
		pretty_json, err := json.MarshalIndent(to_output, "", "    ")
		if err != nil {
			fmt.Println(err)
		}
		out_file.Write(pretty_json)

		fmt.Println(strconv.Itoa(dataPosition) + " " + strconv.Itoa(currLength))
		dataPosition = currLength
		fmt.Println("Wrote data to file")

	}

}
