## Waterloop Backend

A backend system written in Go. Currently takes in UDP pod data (according to PIMP) on port 10001, and represents interally as JSON.

Will also expose this information via a REST API and take pod commands to forward.


#### Building
Install go on your system and follow the setup instructions
`go build *.go` from the project root
`./main` to run

If you want to see output, run the udp_client utility, which will output random data
`./client -packet_length=44`

