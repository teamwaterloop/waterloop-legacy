package main

import (
	"fmt"
	"net"
)

type packet struct {
	data   *[]byte
	length int
}

func udpRecieveThread(packets chan *packet) {
	PORT := ":" + "10001"

	ServerAddr, err := net.ResolveUDPAddr("udp", PORT)
	if err != nil {
		fmt.Printf("Failed to resolve server's address")
		return
	}

	ServerConn, err := net.ListenUDP("udp", ServerAddr)
	if err != nil {
		fmt.Printf("Failed to start UDP listener")
		return
	}
	defer ServerConn.Close()

	buffer := make([]byte, 1024) // We won't we sending data longer than this

	for {
		_, _, err := ServerConn.ReadFromUDP(buffer)
		fmt.Print("Received packet with length ")
		fmt.Print(len(buffer))
		fmt.Print("\n")

		packet := new(packet)

		packet.data = &buffer
		packet.length = len(buffer)

		// This also catches if n > len(buffer)
		if err != nil {
			fmt.Println("Error: ", err)
		}

		// Send packet to channel
		packets <- packet
		fmt.Print("worked")
	}
}
