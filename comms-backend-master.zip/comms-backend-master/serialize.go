package main

import (
	"encoding/binary"
	"fmt"
	"strconv"
	"time"
)

// Define json structs here
type podUpdate struct {
	// populate fields from networking (*bytes) here
	// fields are present in byte the order they are listed here
	Status       uint8 `json:"status"`
	Acceleration int32 `json:"acceleration"`
	Velocity     int32 `json:"velocity"`
	Position     int32 `json:"position"`

	LevFrontLeft  uint16 `json:"levFrontLeft"`
	LevFrontRight uint16 `json:"levFrontRight"`
	LevBackLeft   uint16 `json:"levBackLeft"`
	LevBackRight  uint16 `json:"levBackRight"`

	LevLowPressure  uint16 `json:"levLowPressure"`
	LevHighPressure uint16 `json:"levHighPressure"`

	LevFrontLeftDistance  uint16 `json:"levFrontLeftDistance"`
	LevFrontRightDistance uint16 `json:"levFrontRightDistance"`
	LevBackLeftDistance   uint16 `json:"levBackLeftDistance"`
	LevBackRightDistance  uint16 `json:"levBackRightDistance"`

	XDistance uint16 `json:"xDistance"`
	YDistance uint16 `json:"yDistance"`

	LateralFrontDistance uint16 `json:"lateralFrontDistance"`
	LateralBackDistance  uint16 `json:"lateralBackDistance"`

	BatteryTemperature uint16 `json:"batteryTemperature"`
	BatteryVoltage     uint16 `json:"batteryVoltage"`

	TimeRecieved string `json:"timeRecieved"`
}

func bytesToJSONThread(packetChan chan *packet, jsonValues *[]podUpdate) {

	for {

		packetdata := <-packetChan
		length := packetdata.length
		bytes := packetdata.data

		fmt.Println("packet length: " + string(length))

		if length > 4 {
			data := new(podUpdate)

			// Remember slicing is [min:max+1]
			data.Status = uint8((*bytes)[0])
			data.Acceleration = int32(binary.BigEndian.Uint32((*bytes)[1:5])) // error here!!
			data.Velocity = int32(binary.BigEndian.Uint32((*bytes)[5:9]))
			data.Position = int32(binary.BigEndian.Uint32((*bytes)[9:13]))
			fmt.Println("no error")

			data.LevFrontLeft = binary.BigEndian.Uint16((*bytes)[13:15])
			data.LevFrontRight = binary.BigEndian.Uint16((*bytes)[15:17])
			data.LevBackLeft = binary.BigEndian.Uint16((*bytes)[17:19])
			data.LevBackRight = binary.BigEndian.Uint16((*bytes)[19:21])

			data.LevLowPressure = binary.BigEndian.Uint16((*bytes)[21:23])
			data.LevHighPressure = binary.BigEndian.Uint16((*bytes)[23:25])

			data.LevFrontLeftDistance = binary.BigEndian.Uint16((*bytes)[25:27])
			data.LevFrontRightDistance = binary.BigEndian.Uint16((*bytes)[27:29])
			data.LevBackLeftDistance = binary.BigEndian.Uint16((*bytes)[29:31])
			data.LevBackRightDistance = binary.BigEndian.Uint16((*bytes)[31:33])

			data.XDistance = binary.BigEndian.Uint16((*bytes)[33:35])
			data.YDistance = binary.BigEndian.Uint16((*bytes)[35:37])

			data.LateralFrontDistance = binary.BigEndian.Uint16((*bytes)[37:39])
			data.LateralBackDistance = binary.BigEndian.Uint16((*bytes)[39:41])

			data.BatteryTemperature = binary.BigEndian.Uint16((*bytes)[41:43])
			data.BatteryVoltage = binary.BigEndian.Uint16((*bytes)[43:45])

			time := time.Now()
			data.TimeRecieved = strconv.Itoa(int(time.Unix()))

			*jsonValues = append(*jsonValues, *data)
			fmt.Println("Recieved and stored data")
		}

	}

}
