/*
Main file to run backend
*/

package main

import (
	"time"
)

var rawPackets = make(chan *packet, 512)
var toTransmit = make(chan uint8, 512)
var podData = make([]podUpdate, 0, 65536)

func main() {

	go udpRecieveThread(rawPackets)
	go udpSendThread(toTransmit, "127.0.0.1", "10002")

	go bytesToJSONThread(rawPackets, &podData)
	go outputThread(&podData)

	go runRestAPI(&podData, toTransmit)

	time.Sleep(time.Second * 60)

}
