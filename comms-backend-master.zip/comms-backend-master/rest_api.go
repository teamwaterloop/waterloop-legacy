package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"strconv"

	"github.com/gorilla/mux"
)

func runRestAPI(data *[]podUpdate, toPod chan uint8) {
	router := mux.NewRouter().StrictSlash(true)

	router.HandleFunc("/data/latest/{count:[0-9]+}", getValues).Methods("GET")
	router.HandleFunc("/", test).Methods("GET")
	router.HandleFunc("/command/send", sendCommand).Methods("POST")
	log.Fatal(http.ListenAndServe(":8080", router))
}

// Functions for API endpoints below here

func getValues(w http.ResponseWriter, r *http.Request) {
	requestVars := mux.Vars(r)
	count, _ := strconv.Atoi(requestVars["count"])

	if count < 0 || count > 1024 {
		fmt.Fprintln(w, "Please enter a count between 0 and 1024")
		return
	}

	lastAdded := len(podData)
	firstVal := lastAdded - count

	if firstVal < 0 {
		firstVal = 0
	}

	to_output := podData[firstVal:lastAdded]
	output_json, err := json.MarshalIndent(to_output, "", "    ")
	if err != nil {
		fmt.Println(err)
	}
	fmt.Fprintln(w, string(output_json))

}

func test(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintln(w, "Works")
}

func sendCommand(w http.ResponseWriter, r *http.Request) {
	command, _ := ioutil.ReadAll(r.Body)

	commandStr := string(command)

	commandInt := commandToInt(commandStr)
	if commandInt == -1 {
		fmt.Fprintf(w, "Invalid command")
		return
	}

	toTransmit <- uint8(commandInt)
	fmt.Fprintf(w, "Command sent")
}
