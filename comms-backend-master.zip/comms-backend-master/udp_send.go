package main

import (
	"fmt"
	"net"
	"strconv"
)

// Maps command strings to ints
func commandToInt(command string) int {
	switch command {
	case "emergency_stop":
		return 0
	case "start":
		return 1
	default:
		return -1
	}
}

// Needs to be run as a goroutine
// Sends data to the pod as we recieve the bytes
func udpSendThread(data chan uint8, podIP string, podPort string) {

	address := podIP + ":" + podPort

	ServerAddr, err := net.ResolveUDPAddr("udp", address)
	if err != nil {
		fmt.Println("Failed to resolve remote address of " + address)
		return
	}

	LocalAddr, err := net.ResolveUDPAddr("udp", "127.0.0.1:0")
	if err != nil {
		fmt.Println("Failed to resolve local address. Something is seriously wrong")
		return
	}

	Conn, err := net.DialUDP("udp", LocalAddr, ServerAddr)
	if err != nil {
		fmt.Println("Failed to connect to server")
		panic("Failed to connect to server")
	}
	defer Conn.Close()

	bytedata := make([]byte, 1, 1)

	for {
		packetdata := <-data
		bytedata[0] = packetdata
		_, err := Conn.Write(bytedata)

		if err != nil {
			fmt.Println(string(bytedata), err)
		}
		fmt.Println("Packet sent with value " + strconv.Itoa(int(packetdata)))
	}
}
