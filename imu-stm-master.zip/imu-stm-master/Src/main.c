/**
  ******************************************************************************
  * File Name          : main.c
  * Description        : Main program body
  ******************************************************************************
  *
  * COPYRIGHT(c) 2016 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f7xx_hal.h"
#include "dma.h"
#include "spi.h"
#include "gpio.h"

/* USER CODE BEGIN Includes */
//#include "stm32f7xx_it.h"

/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/
# define ACCEL_XOUT_H ((uint8_t) 0x3b)
# define ACCEL_YOUT_H ((uint8_t) 0x3d)
# define ACCEL_ZOUT_H ((uint8_t) 0x3f)
# define WHO_AM_I ((uint8_t) 0x75)
//#define ITM_Port8(n)    (*((volatile unsigned char *)(0xE0000000+4*n)))
//#define ITM_Port16(n)   (*((volatile unsigned short*)(0xE0000000+4*n)))
//#define ITM_Port32(n)   (*((volatile unsigned long *)(0xE0000000+4*n)))

//#define DEMCR           (*((volatile unsigned long *)(0xE000EDFC)))
//#define TRCENA          0x01000000
int16_t xaccel = 0, yaccel = 0, zaccel = 0;
HAL_StatusTypeDef error1 = 0,error2 = 0;
volatile int isTransferCompleted = 0;
int16_t who_am_i;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void Error_Handler(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/

/* USER CODE END PFP */

/* USER CODE BEGIN 0 */
//struct __FILE { int handle; /* Add whatever needed */ };
//FILE __stdout;
//FILE __stdin;

/*int fputc(int ch, FILE *f) {
  if (DEMCR & TRCENA) {
    while (ITM_Port32(0) == 0);
    ITM_Port8(0) = ch;
  }
  return(ch);
}*/
struct __FILE { int handle; /* Add whatever you need here */ };

FILE __stdout;

FILE __stdin;

int fputc(int ch, FILE *f) {

ITM_SendChar(ch);

return(ch);

}

//Function to transmit data using SPI
void SpiWrite(uint8_t address, uint8_t data){
	
	//Set CS LOW to enable communication
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
	
	// Transmit data
	error1 = HAL_SPI_Transmit(&hspi1, &address, 1, 50);
	error2 = HAL_SPI_Transmit(&hspi1, &data, 1, 50);
	
	//Set CS HIGH to disable communication
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
	HAL_Delay(50);
}

//Function to receive data using SPI
uint8_t SpiRead(uint8_t address){
		uint8_t data; 
		

		//Set CS LOW to enable communication
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
	
		address = address | 0x80;
	
		// Transmit address
		error1 = HAL_SPI_Transmit(&hspi1, &address, 1, 50);
	//	HAL_Delay(1000);
		//Receive data
		error2 = HAL_SPI_Receive(&hspi1, &data, 1, 50);
//		HAL_Delay(1000);
		//Set CS HIGH to disable communication
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
	  HAL_Delay(50);
		return data;
}

//Function to receive data using SPI
uint8_t SpiRead_DMA(uint8_t address){
	
		uint8_t data;
	
		//Set CS LOW to enable communication
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
	
		address += 0x80;
	
		// Transmit address
		HAL_SPI_Transmit(&hspi1, &address, 1, 50);
	
		//Receive data
		while(!isTransferCompleted);
		HAL_SPI_Receive_DMA(&hspi1, &data, 1);
	
		//Set CS HIGH to disable communication
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
		HAL_Delay(50);
		return data;
}

void printAccelData(){
		
	float xaccel_scaled, yaccel_scaled, zaccel_scaled; 
	
	//converting 8 bit unsigned data read to 16 bit signed integer value
	xaccel = (int16_t)(((int16_t)SpiRead(ACCEL_XOUT_H) << 8)|SpiRead(ACCEL_XOUT_H+1));
	yaccel = (int16_t)(((int16_t)SpiRead(ACCEL_YOUT_H) << 8)|SpiRead(ACCEL_YOUT_H+1));
	zaccel = (int16_t)(((int16_t)SpiRead(ACCEL_ZOUT_H) << 8)|SpiRead(ACCEL_ZOUT_H+1));
	
	//Scaling based on 2g Full scale
	xaccel_scaled = xaccel*(1.0/16384.0);
	yaccel_scaled = yaccel*(1.0/16384.0);
	zaccel_scaled = zaccel*(1.0/16384.0);
	printf("X accel = %f, Y accel = %f, Z accel = %f \n", xaccel_scaled, yaccel_scaled, zaccel_scaled);
	
}

void printAccelData_DMA(){
	
	float xaccel_scaled, yaccel_scaled, zaccel_scaled; 
	
  //converting 8 bit unsigned data read to 16 bit signed integer value	
	xaccel = (int16_t)(((int16_t)SpiRead_DMA(ACCEL_XOUT_H) << 8)|SpiRead_DMA(ACCEL_XOUT_H+1));
	yaccel = (int16_t)(((int16_t)SpiRead_DMA(ACCEL_YOUT_H) << 8)|SpiRead_DMA(ACCEL_YOUT_H+1));
	zaccel = (int16_t)(((int16_t)SpiRead_DMA(ACCEL_ZOUT_H) << 8)|SpiRead_DMA(ACCEL_ZOUT_H+1));
	
		//Scaling based on 2g Full scale
	xaccel_scaled = xaccel*(1.0/16384.0);
	yaccel_scaled = yaccel*(1.0/16384.0);
	zaccel_scaled = zaccel*(1.0/16384.0);
	printf("X accel = %d, Y accel = %d, Z accel = %d", xaccel, yaccel, zaccel);
	
}
/* USER CODE END 0 */

int main(void)
{

  /* USER CODE BEGIN 1 */
	
  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* Configure the system clock */
  SystemClock_Config();

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_SPI1_Init();

  /* USER CODE BEGIN 2 */


	//reset device
	SpiWrite( 0x6B, 0x80 );
	HAL_Delay(10);
	
	//disable i2c
	SpiWrite( 0x6A, 0x10 );
	HAL_Delay(10);
	
	//reset acc, gyro and temp
	SpiWrite( 0x68, 0x07 );
  HAL_Delay(10);
	//who_am_i should read 0x71
	who_am_i = SpiRead(WHO_AM_I);
	printf("who am i = %x", who_am_i);
	//while(SpiRead(WHO_AM_I) != 0x71){
	//};
	//isTransferCompleted = 0;
	xaccel = (int16_t)(((int16_t)SpiRead(ACCEL_XOUT_H) << 8)|SpiRead(ACCEL_XOUT_H+1));
	yaccel = (int16_t)(((int16_t)SpiRead(ACCEL_YOUT_H) << 8)|SpiRead(ACCEL_YOUT_H+1));
	zaccel = (int16_t)(((int16_t)SpiRead(ACCEL_ZOUT_H) << 8)|SpiRead(ACCEL_ZOUT_H+1));
	printf("X accel = %x, Y accel = %x, Z accel = %x\n", xaccel, yaccel, zaccel);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
//	xaccel = (int16_t)(((int16_t)SpiRead(ACCEL_XOUT_H) << 8)|SpiRead(ACCEL_XOUT_H+1));
//	yaccel = (int16_t)(((int16_t)SpiRead(ACCEL_YOUT_H) << 8)|SpiRead(ACCEL_YOUT_H+1));
//	zaccel = (int16_t)(((int16_t)SpiRead(ACCEL_ZOUT_H) << 8)|SpiRead(ACCEL_ZOUT_H+1));
//	printf(" X accel = %x, Y accel = %x, Z accel = %x\n", xaccel, yaccel, zaccel);
		printAccelData();
		
		//printAccelData_DMA();
		
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */

  }
  /* USER CODE END 3 */

}

/** System Clock Configuration
*/
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

    /**Configure the main internal regulator output voltage 
    */
  __HAL_RCC_PWR_CLK_ENABLE();

  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler */
  /* User can add his own implementation to report the HAL error return state */
  while(1) 
  {
  }
  /* USER CODE END Error_Handler */ 
}

#ifdef USE_FULL_ASSERT

/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
    ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */

}

#endif

/**
  * @}
  */ 

/**
  * @}
*/ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
