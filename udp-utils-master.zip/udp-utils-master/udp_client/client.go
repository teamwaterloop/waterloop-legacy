/*
A simple UDP client in go
Sends udp packets of a given length containing random data to a given destination server
Usage: ./client -server_ip=$serverIP -server_port=server_port -packet_length=$length
All are optional. Default is localhost:10001 and 32 byte long packets
*/

package main

import (
	"crypto/rand"
	"flag"
	"fmt"
	"net"
	"time"
)

func main() {
	serverIP := flag.String("server_ip", "127.0.0.1", "ip of the server to send data to")
	serverPort := flag.String("server_port", "10001", "port on the server to send data to")

	dataLength := flag.Int("packet_length", 32, "legnth of packet to send")
	flag.Parse()

	address := *serverIP + ":" + *serverPort
	ServerAddr, err := net.ResolveUDPAddr("udp", address)
	if err != nil {
		fmt.Println("Failed to resolve remote address of " + address)
		return
	}

	LocalAddr, err := net.ResolveUDPAddr("udp", "127.0.0.1:0")
	if err != nil {
		fmt.Println("Failed to resolve local address. Something is seriously wrong")
		return
	}

	Conn, err := net.DialUDP("udp", LocalAddr, ServerAddr)
	if err != nil {
		fmt.Println("Failed to connect to server")
		return
	}

	fmt.Println(*dataLength)
	buffer := make([]byte, *dataLength, *dataLength)
	defer Conn.Close()
	for {
		_, _ = rand.Read(buffer)

		_, err := Conn.Write([]byte(buffer))

		if err != nil {
			fmt.Println(string(buffer), err)
		}

		time.Sleep(time.Second * 1)
	}
}
