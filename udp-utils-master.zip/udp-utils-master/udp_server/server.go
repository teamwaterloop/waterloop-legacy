/*
A simple UDP server in GO
Runs continuiously, recieving packets, and prints out their contents
Usage: ./server -port=$port
(port flag optional)
*/

package main

import (
	"flag"
	"fmt"
	"net"
)

func main() {
	port := flag.String("port", "10001", "port to listen on")
	flag.Parse()
	*port = ":" + *port
	ServerAddr, err := net.ResolveUDPAddr("udp", *port)
	if err != nil {
		fmt.Printf("Failed to resolve server's address")
		return
	}

	ServerConn, err := net.ListenUDP("udp", ServerAddr)
	if err != nil {
		fmt.Printf("Failed to start UDP listener")
		return
	}
	defer ServerConn.Close()

	buffer := make([]byte, 512) // We won't we sending data longer than this

	for {
		n, addr, err := ServerConn.ReadFromUDP(buffer)
		fmt.Println("Received packet from ", addr.IP, "\n Length: "+
			string(n)+"\n Raw data: ")
		for i := 0; i < n; i++ {
			fmt.Print(uint8(buffer[i]), " ") // may need to change width of the bit
		}
		fmt.Print("\n\n")

		// This also catches if n > len(buffer)
		if err != nil {
			fmt.Println("Error: ", err)
		}
	}
}
