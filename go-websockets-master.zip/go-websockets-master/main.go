package main

import(
	"net/http"
	"log"
	"github.com/gorilla/websocket"
)



func main() {

	var upgrader = websocket.Upgrader{}  

	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request){
		http.ServeFile(w,r,"index.html")
	})

	http.HandleFunc("/ws", func(w http.ResponseWriter, r *http.Request){

	var conn, _ = upgrader.Upgrade(w, r, nil)

		go func(conn *websocket.Conn){
			for{
				mType, msg, _ := conn.ReadMessage()

				conn.WriteMessage(mType, msg)
			}
		}(conn)
	})


	log.Println("started")

	http.ListenAndServe(":8080", nil)
}
